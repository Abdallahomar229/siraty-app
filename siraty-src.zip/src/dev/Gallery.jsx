// صفحة تطوير بس: كل القوالب بالمثالين (عربي/إنجليزي) — dist/index.html#gallery
import { CvPages } from '../cv/render.jsx'
import { sampleCv } from '../cv/model.js'
import { TEMPLATES } from '../cv/templates.js'

export default function Gallery() {
  const q = new URLSearchParams(location.hash.split('?')[1] || '')
  const only = q.get('t')
  const langs = (q.get('lang') || 'ar,en').split(',')
  const long = q.get('long') === '1'
  return (
    <div style={{ background: '#888', padding: 20, display: 'flex', flexDirection: 'column', gap: 20, alignItems: 'center' }}>
      {TEMPLATES.filter((t) => !only || t.id === only).flatMap((t) =>
        langs.map((lang) => {
          const cv = sampleCv(lang)
          cv.template = t.id
          if (q.get('photo')) cv.photo = q.get('photo') === '1' ? window.__galleryPhoto || PH : ''
          if (q.get('color')) cv.color = q.get('color')
          if (long) cv.experience = [...cv.experience, ...cv.experience.map((x) => ({ ...x, id: x.id + 'b' })), ...cv.experience.map((x) => ({ ...x, id: x.id + 'c' }))]
          return (
            <div key={t.id + lang} className="gal" data-t={t.id} data-lang={lang} style={{ display: 'flex', gap: 20 }}>
              <CvPages cv={cv} plus={q.get('plus') === '1'} />
            </div>
          )
        }),
      )}
    </div>
  )
}
const PH = 'data:image/svg+xml;base64,' + btoa('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" fill="#c9b8a6"/><circle cx="50" cy="40" r="18" fill="#8a7462"/><path d="M15 100c4-22 18-32 35-32s31 10 35 32z" fill="#8a7462"/></svg>')
