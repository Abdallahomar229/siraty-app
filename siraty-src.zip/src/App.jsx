import { AppProvider } from './state/app.jsx'
import { NavProvider, useNav } from './state/nav.jsx'
import { Toast } from './components/ui.jsx'
import Home from './screens/Home.jsx'
import Editor from './screens/Editor.jsx'
import Section from './screens/Section.jsx'
import Preview from './screens/Preview.jsx'
import Paywall from './screens/Paywall.jsx'
import Settings from './screens/Settings.jsx'
import Privacy from './screens/Privacy.jsx'

function Router() {
  const { route, depth } = useNav()
  const key = `${depth}-${route.name}`
  switch (route.name) {
    case 'editor':
      return <Editor key={key} id={route.id} />
    case 'section':
      return <Section key={key} id={route.id} sectionKey={route.key} />
    case 'preview':
      return <Preview key={key} id={route.id} />
    case 'paywall':
      return <Paywall key={key} reason={route.reason} />
    case 'settings':
      return <Settings key={key} />
    case 'privacy':
      return <Privacy key={key} />
    default:
      return <Home key={key} />
  }
}

export default function App() {
  return (
    <AppProvider>
      <NavProvider>
        <Router />
        <Toast />
      </NavProvider>
    </AppProvider>
  )
}
