// «أمثلة جاهزة»: ملخصات وإنجازات ومهارات ومسميات لكل مجال (بلغة السيرة)
import { useState } from 'react'
import { FIELDS, SOFT_SKILLS } from '../content/phrases.js'
import { load, save } from '../lib/storage.js'
import { Sheet } from './ui.jsx'
import { Icon } from './Icons.jsx'

const TITLES = {
  summaries: 'ملخصات جاهزة',
  bullets: 'إنجازات جاهزة',
  skills: 'مهارات مقترحة',
  titles: 'مسميات وظيفية',
}

export default function PhraseSheet({ open, onClose, lang, kind, onPick, used = [] }) {
  const [field, setField] = useState(() => load('field', FIELDS[0].id))
  const f = FIELDS.find((x) => x.id === field) || FIELDS[0]
  const list = f[kind]?.[lang] || []
  const usedSet = new Set(used)
  const pick = (id) => {
    setField(id)
    save('field', id)
  }
  return (
    <Sheet open={open} onClose={onClose} title={TITLES[kind]} tall>
      <div className="field-pick" role="tablist" aria-label="المجال">
        {FIELDS.map((x) => (
          <button key={x.id} type="button" role="tab" aria-selected={x.id === f.id} className={`chip-btn ${x.id === f.id ? 'solid' : ''}`} onClick={() => pick(x.id)}>
            {x.ar}
          </button>
        ))}
      </div>
      {kind === 'skills' ? (
        <>
          <div className="chips">
            {list.map((t) => (
              <button key={t} type="button" className={`chip-btn ${usedSet.has(t) ? 'on' : 'add'}`} onClick={() => onPick(t)}>
                <Icon name={usedSet.has(t) ? 'check' : 'plus'} size={15} stroke={2.4} />
                {t}
              </button>
            ))}
          </div>
          <div className="section-label">
            <span>مهارات شخصية</span>
          </div>
          <div className="chips">
            {SOFT_SKILLS[lang].map((t) => (
              <button key={t} type="button" className={`chip-btn ${usedSet.has(t) ? 'on' : 'add'}`} onClick={() => onPick(t)}>
                <Icon name={usedSet.has(t) ? 'check' : 'plus'} size={15} stroke={2.4} />
                {t}
              </button>
            ))}
          </div>
        </>
      ) : (
        <>
          <p className="field-hint" style={{ margin: '0 2px 10px' }}>
            {kind === 'summaries'
              ? 'اختر الأقرب لك ثم عدّل الأرقام والتفاصيل لتطابق خبرتك.'
              : kind === 'bullets'
                ? 'اضغط لإضافة الإنجاز، ثم عدّل الأرقام لتطابق ما حققته فعلًا.'
                : 'اضغط لاختيار المسمى.'}
          </p>
          {list.map((t) => (
            <button key={t} type="button" className={`phrase ${usedSet.has(t) ? 'used' : ''}`} dir={lang === 'en' ? 'ltr' : 'rtl'} onClick={() => onPick(t)}>
              <Icon name={usedSet.has(t) ? 'check' : 'plus'} size={17} stroke={2.4} />
              <span>{t}</span>
            </button>
          ))}
        </>
      )}
    </Sheet>
  )
}
