// عرض صفحات السيرة مصغّرة بحجم الشاشة
import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { CvPages } from '../cv/render.jsx'

const PW = 793.7
const PH = 1122.5

function useWidth(ref) {
  const [w, setW] = useState(0)
  useLayoutEffect(() => {
    const el = ref.current
    if (!el) return undefined
    const set = () => setW(el.clientWidth)
    set()
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', set)
      return () => window.removeEventListener('resize', set)
    }
    const ro = new ResizeObserver(set)
    ro.observe(el)
    return () => ro.disconnect()
  }, [ref])
  return w
}

// صورة مصغّرة للصفحة الأولى
export function CvThumb({ cv, plus }) {
  const ref = useRef(null)
  const w = useWidth(ref)
  const s = w / PW
  return (
    <div className="thumb" ref={ref} style={{ height: w ? w * (PH / PW) : undefined }}>
      {w > 0 && (
        <div className="scaler" style={{ transform: `scale(${s})` }}>
          <CvPages cv={cv} plus={plus} maxPages={1} />
        </div>
      )}
    </div>
  )
}

// كل الصفحات تحت بعض (للمعاينة)
export function CvPreview({ cv, plus, onLayout, docRef }) {
  const ref = useRef(null)
  const w = useWidth(ref)
  const [count, setCount] = useState(1)
  const s = w / PW
  const gap = 16
  useEffect(() => {
    if (docRef) docRef.current = ref.current
  }, [docRef])
  return (
    <div className="preview-pages" ref={ref} style={{ height: w ? count * PH * s + (count - 1) * gap : undefined }}>
      {w > 0 && (
        <div className="scaler" style={{ transform: `scale(${s})`, '--gap': `${gap / s}px` }}>
          <CvPages
            cv={cv}
            plus={plus}
            className="preview-doc"
            onLayout={(l) => {
              setCount(l.count)
              onLayout?.(l)
            }}
          />
        </div>
      )}
    </div>
  )
}
