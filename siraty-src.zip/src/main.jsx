import { createRoot } from 'react-dom/client'
import './styles/fonts.css'
import './styles/cv.css'
import './styles/app.css'
import App from './App.jsx'
import { initNative } from './lib/native.js'

initNative()

const root = createRoot(document.getElementById('root'))
if (location.hash.startsWith('#gallery')) {
  import('./dev/Gallery.jsx').then(({ default: Gallery }) => {
    document.body.style.overflow = 'auto'
    document.getElementById('root').style.maxWidth = 'none'
    root.render(<Gallery />)
  })
} else {
  root.render(<App />)
}
