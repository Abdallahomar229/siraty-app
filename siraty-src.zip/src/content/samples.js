// «سيرتي» (Siraty) — fictional sample CVs for store screenshots and "start from an example".
// All people, companies, emails, phones and links are fictional.

export const SAMPLES = {
  ar: {
    lang: "ar",
    personal: {
      fullName: "أحمد سمير الشريف",
      jobTitle: "محاسب أول",
      email: "ahmed.elsherif@example.com",
      phone: "+20 100 000 0000",
      location: "القاهرة، مصر",
      website: "",
      linkedin: "linkedin.com/in/ahmed-elsherif-example",
      nationality: "مصري",
      birthDate: "14/05/1992",
    },
    summary:
      "محاسب أول بخبرة تزيد على 10 سنوات في المحاسبة المالية وإعداد التقارير وفق المعايير الدولية IFRS لشركات تجارية وصناعية. قاد تطوير إجراءات الإقفال الشهري وأتمتة التسويات على نظام SAP، مما رفع دقة التقارير وقلص مدة إصدارها إلى النصف. حاصل على شهادة CMA، ويسعى إلى دور قيادي في إدارة مالية تقدر الدقة والتطوير المستمر.",
    experience: [
      {
        id: "e1",
        role: "محاسب أول",
        company: "مجموعة النيل للتجارة",
        location: "القاهرة، مصر",
        start: { m: 3, y: 2021 },
        end: { m: null, y: null },
        current: true,
        bullets:
          "تقليص مدة الإقفال الشهري من 10 إلى 5 أيام عمل عبر توحيد قيود اليومية وأتمتة التسويات على SAP\n" +
          "إعداد القوائم المالية الموحدة لـ 4 شركات تابعة وفق المعايير الدولية IFRS\n" +
          "قيادة التحضير للمراجعة الخارجية السنوية دون أي ملاحظات جوهرية لمدة 3 سنوات متتالية\n" +
          "الإشراف على فريق من 3 محاسبين ومراجعة أعمالهم اليومية وتدريبهم على النظام الجديد",
      },
      {
        id: "e2",
        role: "محاسب تكاليف",
        company: "شركة الأفق للصناعات الغذائية",
        location: "مدينة 6 أكتوبر، مصر",
        start: { m: 7, y: 2017 },
        end: { m: 2, y: 2021 },
        current: false,
        bullets:
          "إعداد تقارير تكاليف الإنتاج الشهرية لـ 3 خطوط إنتاج وتحليل الانحرافات عن الموازنة\n" +
          "بناء نموذج تكاليف على Excel أسهم في تحديد وفورات بنسبة 12% في تكلفة المواد الخام\n" +
          "خفض الذمم المدينة المتأخرة بنسبة 30% خلال 6 أشهر عبر متابعة أسبوعية لأعمار الديون",
      },
      {
        id: "e3",
        role: "محاسب",
        company: "مكتب الراية للمحاسبة والمراجعة",
        location: "القاهرة، مصر",
        start: { m: 9, y: 2014 },
        end: { m: 6, y: 2017 },
        current: false,
        bullets:
          "المشاركة في مراجعة حسابات أكثر من 20 عميلا من الشركات الصغيرة والمتوسطة\n" +
          "إعداد التسويات البنكية ودفاتر الأستاذ لعملاء المكتب بدقة وفي المواعيد المحددة\n" +
          "تجهيز أوراق عمل المراجعة والمستندات المؤيدة لفريق المراجعين الأقدم",
      },
    ],
    education: [
      {
        id: "ed1",
        degree: "بكالوريوس التجارة – شعبة محاسبة",
        school: "كلية التجارة، جامعة القاهرة",
        location: "القاهرة، مصر",
        start: { m: 9, y: 2010 },
        end: { m: 6, y: 2014 },
        current: false,
        details: "التقدير العام: جيد جدا",
      },
    ],
    skills: [
      "المعايير الدولية IFRS",
      "SAP FI/CO",
      "Excel المتقدم",
      "إعداد القوائم المالية",
      "إعداد الموازنات والتنبؤات",
      "محاسبة التكاليف",
      "ضريبة القيمة المضافة",
      "التسويات البنكية",
      "الرقابة الداخلية",
      "Power BI",
    ],
    languages: [
      { id: "l1", name: "العربية", level: "native" },
      { id: "l2", name: "الإنجليزية", level: "advanced" },
      { id: "l3", name: "الفرنسية", level: "basic" },
    ],
    courses: [
      { id: "c1", name: "شهادة المحاسب الإداري المعتمد CMA", org: "معهد المحاسبين الإداريين IMA", year: "2022" },
      { id: "c2", name: "دبلوم المعايير الدولية لإعداد التقارير المالية DipIFR", org: "جمعية المحاسبين القانونيين المعتمدين ACCA", year: "2020" },
    ],
    projects: [
      {
        id: "p1",
        name: "أتمتة التسويات البنكية على SAP",
        link: "",
        details:
          "قيادة مشروع داخلي لأتمتة مطابقة كشوف 15 حسابا بنكيا مع دفتر الأستاذ، مما وفر نحو 20 ساعة عمل شهريا وخفض الفروقات غير المبررة بنسبة 90%",
      },
    ],
  },

  en: {
    lang: "en",
    personal: {
      fullName: "Sara Al-Mansouri",
      jobTitle: "Product Designer",
      email: "sara.almansouri@example.com",
      phone: "+971 50 000 0000",
      location: "Dubai, UAE",
      website: "saraalmansouri.example.com",
      linkedin: "linkedin.com/in/sara-almansouri-example",
      nationality: "Emirati",
      birthDate: "",
    },
    summary:
      "Product designer with 8+ years of experience creating bilingual Arabic-English web and mobile products for fintech and e-commerce. Leads features from user research to launch, turning complex flows into clear, accessible experiences that move business metrics. Built and scaled a design system used by 4 product teams, with deep expertise in right-to-left interface design.",
    experience: [
      {
        id: "e1",
        role: "Senior Product Designer",
        company: "Horizon Fintech",
        location: "Dubai, UAE",
        start: { m: 4, y: 2022 },
        end: { m: null, y: null },
        current: true,
        bullets:
          "Led end-to-end design of a bilingual mobile banking app that reached 250,000+ users in its first year\n" +
          "Redesigned the onboarding and identity verification flow, raising completion from 52% to 78%\n" +
          "Built a Figma design system with 150+ components adopted by 4 product teams, cutting design-to-development handoff time by 40%",
      },
      {
        id: "e2",
        role: "Product Designer",
        company: "Souq Lane",
        location: "Dubai, UAE",
        start: { m: 2, y: 2019 },
        end: { m: 3, y: 2022 },
        current: false,
        bullets:
          "Redesigned the checkout experience, increasing conversion rate by 18% and reducing cart abandonment by 12%\n" +
          "Designed Arabic RTL versions of 60+ screens, ensuring full parity with the English experience\n" +
          "Partnered with engineers to ship 25+ features in 2-week sprints with pixel-accurate implementation",
      },
      {
        id: "e3",
        role: "UI Designer",
        company: "Pixel Bay Studio",
        location: "Sharjah, UAE",
        start: { m: 9, y: 2017 },
        end: { m: 1, y: 2019 },
        current: false,
        bullets:
          "Delivered UI designs for 15+ client websites and apps across retail, hospitality, and education\n" +
          "Created interactive prototypes that helped the studio win 6 new client pitches\n" +
          "Introduced a shared component library that reduced repetitive design work by 30%",
      },
    ],
    education: [
      {
        id: "ed1",
        degree: "Bachelor of Arts in Visual Communication Design",
        school: "Zayed University",
        location: "Dubai, UAE",
        start: { m: 9, y: 2013 },
        end: { m: 6, y: 2017 },
        current: false,
        details: "Graduated with Honors. Graduation project: an Arabic-first wayfinding app for public transport",
      },
    ],
    skills: [
      "Product Design",
      "UX Research",
      "Figma",
      "Interaction Design",
      "Prototyping",
      "Design Systems",
      "Usability Testing",
      "RTL & Bilingual UI",
      "Accessibility (WCAG 2.1)",
      "Framer",
    ],
    languages: [
      { id: "l1", name: "Arabic", level: "native" },
      { id: "l2", name: "English", level: "fluent" },
      { id: "l3", name: "French", level: "basic" },
    ],
    courses: [
      { id: "c1", name: "Google UX Design Professional Certificate", org: "Coursera", year: "2020" },
      { id: "c2", name: "Introduction to Web Accessibility", org: "W3C via edX", year: "2023" },
    ],
    projects: [
      {
        id: "p1",
        name: "Darb – Arabic-First Transit App (Concept)",
        link: "saraalmansouri.example.com/darb",
        details:
          "Self-initiated concept for a bilingual public transport app. Designed RTL navigation patterns and tested them with 12 commuters, reaching a 92% task success rate",
      },
    ],
  },
};
