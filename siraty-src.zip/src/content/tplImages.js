// صور مصغّرة للقوالب (بتتولّد بـ scripts/tpl-thumbs.mjs)
import classic from '../assets/tpl/classic.webp'
import minimal from '../assets/tpl/minimal.webp'
import band from '../assets/tpl/band.webp'
import modern from '../assets/tpl/modern.webp'
import elegant from '../assets/tpl/elegant.webp'
import executive from '../assets/tpl/executive.webp'

export const TPL_IMG = { classic, minimal, band, modern, elegant, executive }
