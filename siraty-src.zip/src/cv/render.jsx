// رسم السيرة على صفحات A4 حقيقية:
// ١) بنقسم السيرة لـ«بلوكات» صغيرة (عنوان قسم، رأس وظيفة، كل نقطة لوحدها…)
// ٢) بنقيس ارتفاع كل بلوك في طبقة مخفية بنفس العرض والخط
// ٣) بنوزّع البلوكات على الصفحات (العنوان ميتفصلش عن أول عنصر تحته)
// نفس الصفحات دي هي اللي بتتطبع PDF، فاللي بتشوفه في المعاينة هو اللي بيطلع بالظبط.
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { LABELS, bulletLines, fmtRange, levelOf, visibleSections } from './model.js'
import { PAGE_H, colorOf, fontOf, geometry, getTemplate, hexA } from './templates.js'

// ───────── أيقونات التواصل (SVG بسيطة) ─────────
const ICONS = {
  email: 'M3 6.5A1.5 1.5 0 0 1 4.5 5h15A1.5 1.5 0 0 1 21 6.5v11a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 17.5v-11Zm2 .9V17h14V7.4l-7 4.8-7-4.8ZM6.6 7l5.4 3.7L17.4 7H6.6Z',
  phone: 'M7.1 3.5c.5 0 .9.3 1.1.7l1.5 3.4c.2.5.1 1-.3 1.4L7.9 10.3a12.4 12.4 0 0 0 5.8 5.8l1.3-1.5c.4-.4.9-.5 1.4-.3l3.4 1.5c.4.2.7.6.7 1.1v2.6c0 .8-.6 1.4-1.4 1.5C10.5 21.4 2.6 13.5 3.1 4.9c.1-.8.7-1.4 1.5-1.4h2.5Z',
  location: 'M12 2.8a7 7 0 0 1 7 7c0 5.2-7 11.4-7 11.4S5 15 5 9.8a7 7 0 0 1 7-7Zm0 4.4a2.6 2.6 0 1 0 0 5.2 2.6 2.6 0 0 0 0-5.2Z',
  link: 'M10.6 13.4a1 1 0 0 1 0-1.4l3.4-3.4a1 1 0 1 1 1.4 1.4L12 13.4a1 1 0 0 1-1.4 0Zm-2.1 5.3a4 4 0 0 1-2.9-6.8l2.1-2.1a1 1 0 0 1 1.4 1.4l-2.1 2.1a2 2 0 0 0 2.9 2.9l2.1-2.1a1 1 0 0 1 1.4 1.4l-2.1 2.1a4 4 0 0 1-2.8 1.1Zm6.3-5.2a1 1 0 0 1-.7-1.7l2.1-2.1a2 2 0 0 0-2.9-2.9l-2.1 2.1a1 1 0 0 1-1.4-1.4l2.1-2.1a4 4 0 0 1 5.7 5.7l-2.1 2.1a1 1 0 0 1-.7.3Z',
  linkedin: 'M5 4h14a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Zm2.2 6.2V17h2.2v-6.8H7.2Zm1.1-3.4a1.2 1.2 0 1 0 0 2.4 1.2 1.2 0 0 0 0-2.4Zm3.2 3.4V17h2.2v-3.6c0-1 .5-1.5 1.2-1.5s1 .5 1 1.5V17h2.2v-4c0-2-1.1-3-2.6-3-1 0-1.5.4-1.9.9v-.7h-2.1Z',
}

function Ico({ k }) {
  return (
    <svg className="cv-ico" viewBox="0 0 24 24" aria-hidden="true">
      <path d={ICONS[k]} fill="currentColor" />
    </svg>
  )
}

// النصوص اللاتينية (إيميل/تليفون/لينك) جوه سيرة عربي لازم تتعزل عشان ترتيبها ميتلخبطش
const Ltr = ({ children }) => (
  <bdi dir="ltr" className="cv-ltr">
    {children}
  </bdi>
)

function contactItems(cv) {
  const p = cv.personal
  const out = []
  if (p.email) out.push({ k: 'email', v: <Ltr>{p.email}</Ltr> })
  if (p.phone) out.push({ k: 'phone', v: <Ltr>{p.phone}</Ltr> })
  if (p.location) out.push({ k: 'location', v: p.location })
  if (p.linkedin) out.push({ k: 'linkedin', v: <Ltr>{p.linkedin.replace(/^https?:\/\/(www\.)?/, '')}</Ltr> })
  if (p.website) out.push({ k: 'link', v: <Ltr>{p.website.replace(/^https?:\/\/(www\.)?/, '')}</Ltr> })
  return out
}

function detailItems(cv, L) {
  const p = cv.personal
  const out = []
  if (p.nationality) out.push({ k: 'nationality', label: L.nationality, v: p.nationality })
  if (p.birthDate) out.push({ k: 'birthDate', label: L.birthDate, v: <Ltr>{p.birthDate}</Ltr> })
  return out
}

function Photo({ cv, tpl, className = '' }) {
  if (!tpl.photo || !cv.photo || !cv.showPhoto) return null
  return <img className={`cv-photo ${className}`} src={cv.photo} alt="" />
}

function ContactInline({ items }) {
  return (
    <div className="cv-contact-inline">
      {items.map((c) => (
        <span key={c.k} className="ci">
          <Ico k={c.k} />
          <span className="v">{c.v}</span>
        </span>
      ))}
    </div>
  )
}

function DetailsInline({ items }) {
  if (!items.length) return null
  return (
    <div className="cv-details-inline">
      {items.map((d) => (
        <span key={d.k} className="di">
          <b>{d.label}:</b> {d.v}
        </span>
      ))}
    </div>
  )
}

// ───────── الرأس (الاسم + المسمى + التواصل) ─────────
function Header({ cv, tpl, L, variant }) {
  const p = cv.personal
  const contacts = contactItems(cv)
  const details = detailItems(cv, L)
  const name = p.fullName || (cv.lang === 'en' ? 'Your Name' : 'اسمك هنا')
  if (variant === 'side') {
    // الرأس في العمود الرئيسي لقالب «حديث»: الاسم والمسمى بس
    return (
      <div className="cv-h">
        <div className="cv-name">{name}</div>
        {p.jobTitle && <div className="cv-role">{p.jobTitle}</div>}
      </div>
    )
  }
  const photo = <Photo cv={cv} tpl={tpl} />
  return (
    <div className={`cv-h ${photo ? 'has-photo' : ''}`}>
      {photo}
      <div className="cv-h-text">
        <div className="cv-name">{name}</div>
        {p.jobTitle && <div className="cv-role">{p.jobTitle}</div>}
        {contacts.length > 0 && <ContactInline items={contacts} />}
        {tpl.layout !== 'sidebar' && <DetailsInline items={details} />}
      </div>
    </div>
  )
}

// ───────── بلوكات الأقسام ─────────
function sectionBlocks(cv, key, L, flow, tpl) {
  const blocks = []
  const add = (k, el, kwn = false) => blocks.push({ k: `${key}:${k}`, el, kwn })
  add(
    't',
    <div className="cv-st">
      <span>{L[key]}</span>
    </div>,
    true,
  )
  const lang = cv.lang
  const inSide = flow === 'side'
  switch (key) {
    case 'summary':
      add('s', <p className="cv-p cv-summary">{cv.summary.trim()}</p>)
      break
    case 'experience':
      cv.experience
        .filter((x) => x.role || x.company)
        .forEach((x, i) => {
          const lines = bulletLines(x.bullets)
          const range = fmtRange(x, lang)
          const sub = [x.company, x.location].filter(Boolean).join(' · ')
          add(
            `${x.id}:h`,
            <div className={`cv-ih ${i === 0 ? 'first' : ''}`}>
              <div className="r1">
                <span className="role">{x.role || x.company}</span>
                {range && <span className="date">{range}</span>}
              </div>
              {x.role && sub && <div className="r2">{sub}</div>}
            </div>,
            lines.length > 0,
          )
          lines.forEach((l, j) =>
            add(
              `${x.id}:b${j}`,
              <div className={`cv-b ${j === lines.length - 1 ? 'last' : ''}`}>{l}</div>,
            ),
          )
        })
      break
    case 'education':
      cv.education
        .filter((x) => x.degree || x.school)
        .forEach((x, i) => {
          const range = fmtRange(x, lang)
          const sub = [x.school, x.location].filter(Boolean).join(' · ')
          add(
            x.id,
            <div className={`cv-ih ${i === 0 ? 'first' : ''}`}>
              <div className="r1">
                <span className="role">{x.degree || x.school}</span>
                {range && !inSide && <span className="date">{range}</span>}
              </div>
              {x.degree && sub && <div className="r2">{sub}</div>}
              {range && inSide && <div className="r3">{range}</div>}
              {x.details.trim() && <div className="cv-p r4">{x.details.trim()}</div>}
            </div>,
          )
        })
      break
    case 'skills':
      if (inSide || tpl.id === 'band') {
        add(
          's',
          <div className="cv-chips">
            {cv.skills.map((s, i) => (
              <span key={i} className="chip">
                {s}
              </span>
            ))}
          </div>,
        )
      } else {
        add(
          's',
          <div className="cv-skills-grid">
            {cv.skills.map((s, i) => (
              <span key={i} className="sk">
                {s}
              </span>
            ))}
          </div>,
        )
      }
      break
    case 'languages': {
      const items = cv.languages.filter((x) => x.name)
      if (inSide) {
        items.forEach((x, i) => {
          const lv = levelOf(x.level)
          add(
            x.id,
            <div className={`cv-lang ${i === 0 ? 'first' : ''}`}>
              <div className="ln">
                <span>{x.name}</span>
                <span className="lv">{lv[lang]}</span>
              </div>
              <div className="dots" aria-hidden="true">
                {[1, 2, 3, 4, 5].map((d) => (
                  <i key={d} className={d <= lv.dots ? 'on' : ''} />
                ))}
              </div>
            </div>,
          )
        })
      } else {
        add(
          's',
          <div className="cv-lang-inline">
            {items.map((x) => (
              <span key={x.id} className="li">
                <b>{x.name}</b> <span className="lv">— {levelOf(x.level)[lang]}</span>
              </span>
            ))}
          </div>,
        )
      }
      break
    }
    case 'courses':
      cv.courses
        .filter((x) => x.name)
        .forEach((x, i) =>
          add(
            x.id,
            <div className={`cv-course ${i === 0 ? 'first' : ''}`}>
              <div className="r1">
                <span className="role">{x.name}</span>
                {x.year && !inSide && (
                  <span className="date">
                    <Ltr>{x.year}</Ltr>
                  </span>
                )}
              </div>
              {(x.org || (inSide && x.year)) && (
                <div className="r2">
                  {x.org}
                  {inSide && x.year && (
                    <>
                      {x.org ? ' · ' : ''}
                      <Ltr>{x.year}</Ltr>
                    </>
                  )}
                </div>
              )}
            </div>,
          ),
        )
      break
    case 'projects':
      cv.projects
        .filter((x) => x.name)
        .forEach((x, i) =>
          add(
            x.id,
            <div className={`cv-ih ${i === 0 ? 'first' : ''}`}>
              <div className="r1">
                <span className="role">{x.name}</span>
              </div>
              {x.link && (
                <div className="r2 link">
                  <Ltr>{x.link.replace(/^https?:\/\/(www\.)?/, '')}</Ltr>
                </div>
              )}
              {x.details.trim() && <div className="cv-p r4">{x.details.trim()}</div>}
            </div>,
          ),
        )
      break
    default:
      break
  }
  return blocks
}

// بيرجّع: الرأس الكامل (لو القالب بيستخدمه) + بلوكات العمود الرئيسي + بلوكات العمود الجانبي
export function buildFlows(cv, tpl) {
  const L = LABELS[cv.lang]
  const keys = visibleSections(cv)
  const sideKeys = tpl.layout === 'single' ? [] : tpl.side || []
  const main = []
  const side = []
  let header = null

  if (tpl.fullHeader) header = <Header cv={cv} tpl={tpl} L={L} />
  else if (tpl.layout === 'sidebar') main.push({ k: 'header', el: <Header cv={cv} tpl={tpl} L={L} variant="side" /> })
  else main.push({ k: 'header', el: <Header cv={cv} tpl={tpl} L={L} /> })

  if (tpl.layout === 'sidebar') {
    // العمود الجانبي: الصورة + التواصل + البيانات الشخصية
    const photo = <Photo cv={cv} tpl={tpl} className="side" />
    if (photo) side.push({ k: 'photo', el: <div className="cv-side-photo">{photo}</div> })
    const contacts = contactItems(cv)
    if (contacts.length) {
      side.push({ k: 'contact:t', el: <div className="cv-st"><span>{L.contact}</span></div>, kwn: true })
      contacts.forEach((c) =>
        side.push({
          k: `contact:${c.k}`,
          el: (
            <div className="cv-contact-row">
              <Ico k={c.k} />
              <span className="v">{c.v}</span>
            </div>
          ),
        }),
      )
    }
    const details = detailItems(cv, L)
    if (details.length) {
      side.push({ k: 'details:t', el: <div className="cv-st"><span>{L.details}</span></div>, kwn: true })
      details.forEach((d) =>
        side.push({
          k: `details:${d.k}`,
          el: (
            <div className="cv-detail-row">
              <span className="dl">{d.label}</span>
              <span className="v">{d.v}</span>
            </div>
          ),
        }),
      )
    }
  }

  for (const key of keys) {
    const flow = sideKeys.includes(key) ? 'side' : 'main'
    const list = sectionBlocks(cv, key, L, flow, tpl)
    ;(flow === 'side' ? side : main).push(...list)
  }
  // أول عنوان قسم في كل عمود من غير مسافة فوقه
  for (const list of [main, side]) {
    const first = list.find((b) => b.k.endsWith(':t'))
    if (first && list.indexOf(first) === 0) first.first = true
  }
  return { header, main, side }
}

// توزيع البلوكات على الصفحات
function paginate(heights, blocks, capOf) {
  const pageOf = []
  let page = 0
  let used = 0
  for (let i = 0; i < blocks.length; i++) {
    const h = heights[i] || 0
    let need = h
    if (blocks[i].kwn && i + 1 < blocks.length) need += heights[i + 1] || 0
    if (used > 0 && used + need > capOf(page)) {
      page += 1
      used = 0
    }
    pageOf.push(page)
    used += h
  }
  return pageOf
}

// بيعيد القياس لما الخطوط تخلص تحميل
function useFontsTick(family) {
  const [tick, setTick] = useState(0)
  useEffect(() => {
    let alive = true
    const bump = () => alive && setTick((t) => t + 1)
    try {
      const f = document.fonts
      if (f) {
        Promise.all([
          f.load(`400 16px "${family}"`, 'سيرة Aa'),
          f.load(`700 16px "${family}"`, 'سيرة Aa'),
        ])
          .then(() => f.ready)
          .then(bump, bump)
        f.addEventListener?.('loadingdone', bump)
        return () => {
          alive = false
          f.removeEventListener?.('loadingdone', bump)
        }
      }
    } catch {
      /* تجاهل */
    }
    return () => {
      alive = false
    }
  }, [family])
  return tick
}

function Column({ blocks, flow, g }) {
  if (!g) return null
  return (
    <div className={`cv-col cv-${flow}`} style={{ top: g.top, insetInlineStart: g.start, width: g.width }}>
      {blocks.map((b) => (
        <div key={b.k} className={`blk ${b.first ? 'first' : ''}`}>
          {b.el}
        </div>
      ))}
    </div>
  )
}

/**
 * <CvPages cv plus maxPages onLayout />
 * بيرسم صفحات السيرة (كل صفحة div بمقاس A4 بالظبط)
 */
export function CvPages({ cv, plus = false, maxPages = 0, onLayout, className = '' }) {
  const tpl = getTemplate(cv.template)
  const color = colorOf(cv, tpl)
  const font = fontOf(cv, tpl)
  const flows = useMemo(() => buildFlows(cv, tpl), [cv, tpl])
  const measureRef = useRef(null)
  const [layout, setLayout] = useState(null)
  const tick = useFontsTick(font.family)

  useLayoutEffect(() => {
    const root = measureRef.current
    if (!root) return
    // المعاينة متصغّرة بـtransform، فبنقسم على معامل التصغير عشان نرجع للمقاس الحقيقي
    const pageEl = root.firstElementChild
    const k = pageEl && pageEl.offsetWidth ? pageEl.getBoundingClientRect().width / pageEl.offsetWidth || 1 : 1
    const h = (el) => el.getBoundingClientRect().height / k
    const hEl = root.querySelector('.m-header')
    const headerH = hEl ? Math.ceil(h(hEl)) : 0
    const read = (flow) => Array.from(root.querySelectorAll(`.m-${flow} > .blk`)).map((el) => h(el))
    const capOf = (flow) => (i) => {
      const g = geometry(tpl, i, headerH)[flow]
      return g ? g.cap - 4 : PAGE_H
    }
    const mainPages = paginate(read('main'), flows.main, capOf('main'))
    const sidePages = paginate(read('side'), flows.side, capOf('side'))
    const count = Math.max(1, (mainPages.length ? mainPages[mainPages.length - 1] : 0) + 1, (sidePages.length ? sidePages[sidePages.length - 1] : 0) + 1)
    const next = { headerH, mainPages, sidePages, count }
    setLayout((prev) =>
      prev &&
      prev.headerH === headerH &&
      prev.count === count &&
      prev.mainPages.join() === mainPages.join() &&
      prev.sidePages.join() === sidePages.join()
        ? prev
        : next,
    )
  }, [flows, tpl, tick])

  const onLayoutRef = useRef(onLayout)
  onLayoutRef.current = onLayout
  useEffect(() => {
    if (layout) onLayoutRef.current?.(layout)
  }, [layout])

  const vars = {
    '--c': color,
    '--c06': hexA(color, 0.06),
    '--c12': hexA(color, 0.12),
    '--c20': hexA(color, 0.2),
    '--c40': hexA(color, 0.4),
  }
  const dir = cv.lang === 'en' ? 'ltr' : 'rtl'
  const cls = `cv-page tpl-${tpl.id} f-${font.id} lang-${cv.lang}`
  const g0 = geometry(tpl, 0, 0)
  const L = LABELS[cv.lang]

  const pages = []
  if (layout && layout.mainPages.length === flows.main.length && layout.sidePages.length === flows.side.length) {
    const n = maxPages ? Math.min(maxPages, layout.count) : layout.count
    for (let i = 0; i < n; i++) {
      const g = geometry(tpl, i, layout.headerH)
      const main = flows.main.filter((_, j) => layout.mainPages[j] === i)
      const side = flows.side.filter((_, j) => layout.sidePages[j] === i)
      pages.push(
        <div key={i} className={cls} dir={dir} lang={cv.lang} style={vars} data-page={i + 1}>
          {tpl.sideBg && <div className="cv-side-bg" style={{ insetInlineStart: tpl.sideBg.start, width: tpl.sideBg.width }} />}
          {i === 0 && flows.header && <div className="cv-fh">{flows.header}</div>}
          <Column blocks={main} flow="main" g={g.main} />
          <Column blocks={side} flow="side" g={g.side} />
          {!plus && i === layout.count - 1 && <div className="cv-wm">{L.watermark}</div>}
        </div>,
      )
    }
  }

  return (
    <div className={`cv-doc ${className}`}>
      <div className="cv-measure" ref={measureRef} aria-hidden="true">
        <div className={cls} dir={dir} lang={cv.lang} style={{ ...vars, height: 'auto', minHeight: 0 }}>
          {flows.header && <div className="cv-fh m-header">{flows.header}</div>}
          <div className="cv-col cv-main m-main" style={{ position: 'relative', width: g0.main.width }}>
            {flows.main.map((b) => (
              <div key={b.k} className={`blk ${b.first ? 'first' : ''}`}>
                {b.el}
              </div>
            ))}
          </div>
          {g0.side && (
            <div className="cv-col cv-side m-side" style={{ position: 'relative', width: g0.side.width }}>
              {flows.side.map((b) => (
                <div key={b.k} className={`blk ${b.first ? 'first' : ''}`}>
                  {b.el}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      {pages}
    </div>
  )
}
