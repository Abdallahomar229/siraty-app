// «قوة السيرة»: درجة من 100 + أهم الخطوات الناقصة (بالترتيب حسب الأهمية)
import { bulletLines } from './model.js'

export function strength(cv) {
  const p = cv.personal
  const checks = []
  const add = (ok, pts, tip, section) => checks.push({ ok, pts, tip, section })

  add(!!p.fullName.trim(), 10, 'اكتب اسمك الكامل', 'personal')
  add(!!p.jobTitle.trim(), 6, 'أضف المسمى الوظيفي الذي تتقدم له', 'personal')
  add(/.+@.+\..+/.test(p.email), 6, 'أضف بريدًا إلكترونيًا للتواصل', 'personal')
  add(p.phone.replace(/\D/g, '').length >= 7, 5, 'أضف رقم الهاتف', 'personal')
  add(!!p.location.trim(), 3, 'اكتب مدينتك ودولتك', 'personal')

  const sum = cv.summary.trim().length
  add(sum >= 140, 15, sum ? 'اجعل الملخص المهني من جملتين إلى ثلاث' : 'اكتب ملخصًا مهنيًا قصيرًا (أو اختر مثالًا جاهزًا)', 'summary')

  const jobs = cv.experience.filter((x) => x.role || x.company)
  const lines = jobs.flatMap((x) => bulletLines(x.bullets))
  add(jobs.length > 0, 14, 'أضف خبرة عملية (أو تدريبًا أو عملًا تطوعيًا إن كنت حديث التخرج)', 'experience')
  add(jobs.length > 0 && lines.length >= jobs.length * 2, 6, 'أضف إنجازين على الأقل لكل وظيفة', 'experience')
  add(lines.some((l) => /\d/.test(l)), 5, 'استخدم أرقامًا في الإنجازات (نسبة، عدد، مدة)', 'experience')
  add(jobs.every((x) => x.start?.y), 3, 'حدّد تاريخ البداية لكل وظيفة', 'experience')

  add(cv.education.some((x) => x.degree || x.school), 10, 'أضف مؤهلك الدراسي', 'education')
  add(cv.skills.length >= 6, 9, cv.skills.length ? 'أضف مهارات أكثر (من 6 إلى 12)' : 'أضف مهاراتك', 'skills')
  add(cv.languages.some((x) => x.name), 4, 'أضف اللغات التي تتحدثها', 'languages')
  add(cv.courses.some((x) => x.name) || cv.projects.some((x) => x.name), 4, 'أضف دورة أو شهادة أو مشروعًا', 'courses')

  const total = checks.reduce((n, c) => n + c.pts, 0)
  const got = checks.filter((c) => c.ok).reduce((n, c) => n + c.pts, 0)
  const score = Math.round((got / total) * 100)
  const todo = checks.filter((c) => !c.ok).sort((a, b) => b.pts - a.pts)
  const label = score >= 85 ? 'ممتازة' : score >= 65 ? 'قوية' : score >= 40 ? 'متوسطة' : 'في البداية'
  return { score, label, todo }
}
