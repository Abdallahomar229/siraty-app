// نموذج بيانات السيرة الذاتية + النصوص اللي بتظهر جوه السيرة (عربي/إنجليزي)
import { SAMPLES } from '../content/samples.js'

export const SECTION_KEYS = ['summary', 'experience', 'education', 'skills', 'languages', 'courses', 'projects']

export const LABELS = {
  ar: {
    summary: 'الملخص المهني',
    experience: 'الخبرات العملية',
    education: 'التعليم',
    skills: 'المهارات',
    languages: 'اللغات',
    courses: 'الدورات والشهادات',
    projects: 'المشاريع',
    contact: 'التواصل',
    details: 'بيانات شخصية',
    nationality: 'الجنسية',
    birthDate: 'تاريخ الميلاد',
    present: 'حتى الآن',
    watermark: 'صُمّمت بتطبيق «سيرتي»',
  },
  en: {
    summary: 'Professional Summary',
    experience: 'Work Experience',
    education: 'Education',
    skills: 'Skills',
    languages: 'Languages',
    courses: 'Courses & Certifications',
    projects: 'Projects',
    contact: 'Contact',
    details: 'Personal Details',
    nationality: 'Nationality',
    birthDate: 'Date of Birth',
    present: 'Present',
    watermark: 'Made with the Siraty app',
  },
}

export const LEVELS = [
  { id: 'native', ar: 'اللغة الأم', en: 'Native', dots: 5 },
  { id: 'fluent', ar: 'طلاقة تامة', en: 'Fluent', dots: 5 },
  { id: 'advanced', ar: 'متقدم', en: 'Advanced', dots: 4 },
  { id: 'intermediate', ar: 'متوسط', en: 'Intermediate', dots: 3 },
  { id: 'basic', ar: 'مبتدئ', en: 'Basic', dots: 2 },
]

export const MONTHS = {
  ar: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
  en: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
}

export function uid(prefix = 'x') {
  return `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`
}

const emptyDate = () => ({ m: null, y: null })

export const BLANK_ITEM = {
  experience: () => ({ id: uid('e'), role: '', company: '', location: '', start: emptyDate(), end: emptyDate(), current: false, bullets: '' }),
  education: () => ({ id: uid('d'), degree: '', school: '', location: '', start: emptyDate(), end: emptyDate(), current: false, details: '' }),
  languages: () => ({ id: uid('l'), name: '', level: 'intermediate' }),
  courses: () => ({ id: uid('c'), name: '', org: '', year: '' }),
  projects: () => ({ id: uid('p'), name: '', link: '', details: '' }),
}

export function blankCv(lang = 'ar') {
  return normalize({ lang })
}

export function sampleCv(lang = 'ar') {
  const s = JSON.parse(JSON.stringify(SAMPLES[lang] || SAMPLES.ar))
  return normalize({ ...s, title: s.personal?.fullName || '' })
}

function arr(v) {
  return Array.isArray(v) ? v : []
}

function str(v) {
  return typeof v === 'string' ? v : v == null ? '' : String(v)
}

function date(v) {
  const m = Number(v?.m)
  const y = Number(v?.y)
  return { m: m >= 1 && m <= 12 ? m : null, y: y >= 1950 && y <= 2100 ? y : null }
}

// بيضمن إن أي سيرة (قديمة أو ناقصة) فيها كل الحقول بالشكل الصح
export function normalize(raw = {}) {
  const lang = raw.lang === 'en' ? 'en' : 'ar'
  const p = raw.personal || {}
  const order = arr(raw.order).filter((k) => SECTION_KEYS.includes(k))
  for (const k of SECTION_KEYS) if (!order.includes(k)) order.push(k)
  return {
    id: str(raw.id) || uid('cv'),
    title: str(raw.title),
    lang,
    template: str(raw.template) || 'classic',
    color: str(raw.color) || '',
    font: str(raw.font) || '',
    photo: typeof raw.photo === 'string' && raw.photo.startsWith('data:image/') ? raw.photo : '',
    showPhoto: raw.showPhoto !== false,
    createdAt: Number(raw.createdAt) || Date.now(),
    updatedAt: Number(raw.updatedAt) || Date.now(),
    order,
    hidden: { ...(raw.hidden || {}) },
    personal: {
      fullName: str(p.fullName),
      jobTitle: str(p.jobTitle),
      email: str(p.email),
      phone: str(p.phone),
      location: str(p.location),
      website: str(p.website),
      linkedin: str(p.linkedin),
      nationality: str(p.nationality),
      birthDate: str(p.birthDate),
    },
    summary: str(raw.summary),
    experience: arr(raw.experience).map((x) => ({
      ...BLANK_ITEM.experience(),
      ...x,
      id: str(x?.id) || uid('e'),
      start: date(x?.start),
      end: date(x?.end),
      current: !!x?.current,
      bullets: str(x?.bullets),
    })),
    education: arr(raw.education).map((x) => ({
      ...BLANK_ITEM.education(),
      ...x,
      id: str(x?.id) || uid('d'),
      start: date(x?.start),
      end: date(x?.end),
      current: !!x?.current,
      details: str(x?.details),
    })),
    skills: arr(raw.skills).map(str).filter(Boolean),
    languages: arr(raw.languages).map((x) => ({
      ...BLANK_ITEM.languages(),
      ...x,
      id: str(x?.id) || uid('l'),
      level: LEVELS.some((l) => l.id === x?.level) ? x.level : 'intermediate',
    })),
    courses: arr(raw.courses).map((x) => ({ ...BLANK_ITEM.courses(), ...x, id: str(x?.id) || uid('c'), year: str(x?.year) })),
    projects: arr(raw.projects).map((x) => ({ ...BLANK_ITEM.projects(), ...x, id: str(x?.id) || uid('p') })),
  }
}

export function fmtDate(d, lang) {
  if (!d || !d.y) return ''
  return d.m ? `${MONTHS[lang][d.m - 1]} ${d.y}` : String(d.y)
}

export function fmtRange(item, lang) {
  const a = fmtDate(item.start, lang)
  const b = item.current ? LABELS[lang].present : fmtDate(item.end, lang)
  if (a && b) return `${a} – ${b}`
  return a || b
}

export function bulletLines(text) {
  return str(text)
    .split('\n')
    .map((l) => l.replace(/^\s*[-•·*▪●]\s*/, '').trim())
    .filter(Boolean)
}

export function levelOf(id) {
  return LEVELS.find((l) => l.id === id) || LEVELS[3]
}

// هل القسم فيه محتوى يظهر في السيرة؟
export function hasContent(cv, key) {
  switch (key) {
    case 'summary':
      return !!cv.summary.trim()
    case 'skills':
      return cv.skills.length > 0
    case 'experience':
      return cv.experience.some((x) => x.role || x.company)
    case 'education':
      return cv.education.some((x) => x.degree || x.school)
    case 'languages':
      return cv.languages.some((x) => x.name)
    case 'courses':
      return cv.courses.some((x) => x.name)
    case 'projects':
      return cv.projects.some((x) => x.name)
    default:
      return false
  }
}

export function visibleSections(cv) {
  return cv.order.filter((k) => !cv.hidden[k] && hasContent(cv, k))
}

export function cvDisplayName(cv) {
  return cv.title || cv.personal.fullName || (cv.lang === 'en' ? 'My CV' : 'سيرتي الذاتية')
}

export function fileName(cv) {
  const n = (cv.personal.fullName || cvDisplayName(cv)).replace(/[\\/:*?"<>|]+/g, ' ').trim().replace(/\s+/g, '-')
  return `${n || 'CV'}-CV`
}
