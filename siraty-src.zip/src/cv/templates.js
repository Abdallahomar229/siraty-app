// القوالب: الشكل (CSS في styles/cv.css) + هندسة الصفحة (هنا) عشان ترقيم الصفحات يبقى مظبوط
// كل المقاسات بالبكسل على صفحة A4 = 794 × 1122 (‎96dpi)
export const PAGE_W = 794
export const PAGE_H = 1122

export const COLORS = [
  { id: 'navy', hex: '#1F3A5F' },
  { id: 'teal', hex: '#0E6B60' },
  { id: 'green', hex: '#2F6B3E' },
  { id: 'blue', hex: '#2456C6' },
  { id: 'wine', hex: '#8A2B3C' },
  { id: 'brown', hex: '#8A5A1C' },
  { id: 'purple', hex: '#55388F' },
  { id: 'charcoal', hex: '#2E333B' },
]

export const FONTS = [
  { id: 'plex', name: 'بلكس', family: 'Plex', sample: 'سيرة Aa' },
  { id: 'cairo', name: 'القاهرة', family: 'Cairo', sample: 'سيرة Aa' },
  { id: 'tajawal', name: 'تجوّل', family: 'Tajawal', sample: 'سيرة Aa' },
  { id: 'amiri', name: 'أميري', family: 'Amiri', sample: 'سيرة Aa' },
]

// layout: single = عمود واحد | sidebar = شريط جانبي ملوّن | split = رأس كامل + عمودين
// side: الأقسام اللي بتروح العمود الجانبي
export const TEMPLATES = [
  {
    id: 'classic',
    name: 'كلاسيكي',
    plus: false,
    ats: true,
    layout: 'single',
    font: 'plex',
    color: 'navy',
    photo: true,
    pad: { t: 50, b: 50, x: 56 },
  },
  {
    id: 'minimal',
    name: 'بسيط',
    plus: false,
    ats: true,
    layout: 'single',
    font: 'plex',
    color: 'charcoal',
    photo: false,
    pad: { t: 58, b: 50, x: 64 },
  },
  {
    id: 'band',
    name: 'مهني',
    plus: false,
    ats: true,
    layout: 'single',
    fullHeader: true,
    font: 'cairo',
    color: 'teal',
    photo: true,
    pad: { t: 46, b: 50, x: 52, afterHeader: 26 },
  },
  {
    id: 'modern',
    name: 'حديث',
    plus: true,
    layout: 'sidebar',
    font: 'plex',
    color: 'navy',
    photo: true,
    side: ['skills', 'languages'],
    pad: { t: 44, b: 46 },
    sideBg: { start: 0, width: 254 },
    cols: { side: { start: 26, width: 202, top: 40 }, main: { start: 288, width: 466 } },
  },
  {
    id: 'elegant',
    name: 'أنيق',
    plus: true,
    layout: 'single',
    font: 'amiri',
    color: 'wine',
    photo: false,
    pad: { t: 54, b: 50, x: 66 },
  },
  {
    id: 'executive',
    name: 'تنفيذي',
    plus: true,
    layout: 'split',
    fullHeader: true,
    font: 'tajawal',
    color: 'charcoal',
    photo: true,
    side: ['skills', 'languages', 'courses'],
    pad: { t: 40, b: 46, afterHeader: 28 },
    sideBg: { start: 528, width: 266 },
    cols: { main: { start: 40, width: 460 }, side: { start: 550, width: 220 } },
  },
]

export function getTemplate(id) {
  return TEMPLATES.find((t) => t.id === id) || TEMPLATES[0]
}

export function colorOf(cv, tpl) {
  if (cv.color && /^#[0-9a-f]{6}$/i.test(cv.color)) return cv.color
  return (COLORS.find((c) => c.id === (cv.color || tpl.color)) || COLORS.find((c) => c.id === tpl.color) || COLORS[0]).hex
}

export function fontOf(cv, tpl) {
  return FONTS.find((f) => f.id === (cv.font || tpl.font)) || FONTS[0]
}

// مكان وعرض كل عمود في صفحة رقم i (headerH = ارتفاع الرأس الكامل في الصفحة الأولى)
export function geometry(tpl, i, headerH = 0) {
  const p = tpl.pad
  const top = (base) => (i === 0 && tpl.fullHeader ? headerH + (p.afterHeader || 24) : base)
  if (tpl.layout === 'single') {
    const t = top(p.t)
    return { main: { start: p.x, width: PAGE_W - 2 * p.x, top: t, cap: PAGE_H - t - p.b } }
  }
  const c = tpl.cols
  const mt = top(p.t)
  const st = top(c.side.top || p.t)
  return {
    main: { start: c.main.start, width: c.main.width, top: mt, cap: PAGE_H - mt - p.b },
    side: { start: c.side.start, width: c.side.width, top: st, cap: PAGE_H - st - p.b },
  }
}

export function hexA(hex, a) {
  const n = parseInt(hex.slice(1), 16)
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`
}
