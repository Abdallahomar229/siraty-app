// شاشة تعديل قسم واحد من السيرة
import { useState } from 'react'
import { useApp, useCv } from '../state/app.jsx'
import { Icon } from '../components/Icons.jsx'
import { Confirm, Field, Screen, Segmented, TextArea, Tip, Toggle } from '../components/ui.jsx'
import PhraseSheet from '../components/PhraseSheet.jsx'
import { TIPS } from '../content/phrases.js'
import { BLANK_ITEM, LEVELS, MONTHS, bulletLines, fmtRange } from '../cv/model.js'
import { readPhoto } from '../lib/image.js'
import { SECTION_NAMES } from './Editor.jsx'

const YEARS = (() => {
  const now = new Date().getFullYear() + 4
  const out = []
  for (let y = now; y >= 1965; y--) out.push(y)
  return out
})()

function DatePick({ label, value, onChange, disabled }) {
  return (
    <div className="field">
      <label>{label}</label>
      <div className="date-row">
        <select value={value?.m || ''} disabled={disabled} onChange={(e) => onChange({ ...value, m: Number(e.target.value) || null })} aria-label={`${label} — الشهر`}>
          <option value="">الشهر</option>
          {MONTHS.ar.map((m, i) => (
            <option key={m} value={i + 1}>
              {m}
            </option>
          ))}
        </select>
        <select value={value?.y || ''} disabled={disabled} onChange={(e) => onChange({ ...value, y: Number(e.target.value) || null })} aria-label={`${label} — السنة`}>
          <option value="">السنة</option>
          {YEARS.map((y) => (
            <option key={y} value={y}>
              {y}
            </option>
          ))}
        </select>
      </div>
    </div>
  )
}

// ───────── البيانات الشخصية ─────────
function Personal({ cv, update }) {
  const { toast } = useApp()
  const [titles, setTitles] = useState(false)
  const p = cv.personal
  const set = (k) => (v) => update((c) => ({ ...c, personal: { ...c.personal, [k]: v } }))
  const tips = TIPS[cv.lang] || TIPS.ar
  const onPhoto = async (e) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    try {
      const photo = await readPhoto(file)
      update({ photo, showPhoto: true })
    } catch {
      toast('تعذّر فتح الصورة، جرّب صورة أخرى')
    }
  }
  return (
    <>
      <Tip>{tips.personal}</Tip>
      <div className="photo-row">
        <label className="photo-pick" aria-label="اختيار صورة شخصية">
          {cv.photo ? <img src={cv.photo} alt="" /> : <Icon name="camera" size={28} />}
          <input type="file" accept="image/*" onChange={onPhoto} />
        </label>
        <div className="photo-side">
          <b>الصورة الشخصية (اختياري)</b>
          <small>تظهر في قوالب: كلاسيكي، مهني، حديث، تنفيذي.</small>
          {cv.photo ? (
            <button type="button" className="link" style={{ color: 'var(--danger)', padding: '2px 0' }} onClick={() => update({ photo: '' })}>
              حذف الصورة
            </button>
          ) : null}
        </div>
      </div>
      {cv.photo ? (
        <div style={{ marginBottom: 16 }}>
          <Toggle label="إظهار الصورة في السيرة" sub="بعض الشركات الدولية تفضّل السيرة بدون صورة" checked={cv.showPhoto} onChange={(v) => update({ showPhoto: v })} />
        </div>
      ) : null}
      <Field label="الاسم الكامل" value={p.fullName} onChange={set('fullName')} placeholder={cv.lang === 'en' ? 'Ahmed Samir' : 'مثال: أحمد سمير الشريف'} autoComplete="name" dir="auto" />
      <TextArea
        label="المسمى الوظيفي"
        rows={1}
        value={p.jobTitle}
        onChange={(v) => set('jobTitle')(v.replace(/\n/g, ' '))}
        placeholder={cv.lang === 'en' ? 'Senior Accountant' : 'مثال: محاسب أول'}
        dir="auto"
        tools={
          <button type="button" className="examples-btn" onClick={() => setTitles(true)}>
            <Icon name="sparkle" size={14} /> اقتراحات
          </button>
        }
      />
      <Field label="البريد الإلكتروني" type="email" inputMode="email" dir="ltr" value={p.email} onChange={set('email')} placeholder="name@example.com" autoComplete="email" />
      <Field label="رقم الهاتف" type="tel" inputMode="tel" dir="ltr" value={p.phone} onChange={set('phone')} placeholder="+20 100 000 0000" autoComplete="tel" />
      <Field label="المدينة والدولة" value={p.location} onChange={set('location')} placeholder={cv.lang === 'en' ? 'Cairo, Egypt' : 'مثال: القاهرة، مصر'} dir="auto" />
      <Field label="رابط LinkedIn (اختياري)" dir="ltr" inputMode="url" value={p.linkedin} onChange={set('linkedin')} placeholder="linkedin.com/in/your-name" />
      <Field label="موقع شخصي أو معرض أعمال (اختياري)" dir="ltr" inputMode="url" value={p.website} onChange={set('website')} placeholder="yourname.com" />
      <div className="grid2">
        <Field label="الجنسية (اختياري)" value={p.nationality} onChange={set('nationality')} dir="auto" />
        <Field label="تاريخ الميلاد (اختياري)" value={p.birthDate} onChange={set('birthDate')} dir="ltr" placeholder="14/05/1995" />
      </div>
      <PhraseSheet
        open={titles}
        onClose={() => setTitles(false)}
        lang={cv.lang}
        kind="titles"
        used={[p.jobTitle]}
        onPick={(t) => {
          set('jobTitle')(t)
          setTitles(false)
        }}
      />
    </>
  )
}

// ───────── الملخص ─────────
function Summary({ cv, update }) {
  const [ex, setEx] = useState(false)
  const [replaceAsk, setReplaceAsk] = useState(null)
  const tips = TIPS[cv.lang] || TIPS.ar
  return (
    <>
      <Tip>{tips.summary}</Tip>
      <TextArea
        label="الملخص المهني"
        value={cv.summary}
        rows={7}
        dir="auto"
        counter={[200, 600]}
        hint="الأفضل من 250 إلى 450 حرفًا"
        onChange={(v) => update({ summary: v })}
        placeholder={cv.lang === 'en' ? 'Results-driven accountant with 6+ years of experience…' : 'مثال: محاسب بخبرة 6 سنوات في…'}
        tools={
          <button type="button" className="examples-btn" onClick={() => setEx(true)}>
            <Icon name="sparkle" size={14} /> أمثلة جاهزة
          </button>
        }
      />
      <PhraseSheet
        open={ex}
        onClose={() => setEx(false)}
        lang={cv.lang}
        kind="summaries"
        used={[cv.summary.trim()]}
        onPick={(t) => {
          setEx(false)
          if (cv.summary.trim() && cv.summary.trim() !== t) setReplaceAsk(t)
          else update({ summary: t })
        }}
      />
      <Confirm
        open={!!replaceAsk}
        title="استبدال الملخص الحالي؟"
        text="سيحل المثال محل ما كتبته. يمكنك تعديله بعد ذلك."
        yes="استبدال"
        onYes={() => {
          update({ summary: replaceAsk })
          setReplaceAsk(null)
        }}
        onNo={() => setReplaceAsk(null)}
      />
    </>
  )
}

// ───────── المهارات ─────────
function Skills({ cv, update }) {
  const [text, setText] = useState('')
  const [ex, setEx] = useState(false)
  const tips = TIPS[cv.lang] || TIPS.ar
  const add = (raw) => {
    const parts = String(raw)
      .split(/[,،\n]/)
      .map((s) => s.trim())
      .filter(Boolean)
    if (!parts.length) return
    update((c) => {
      const have = new Set(c.skills.map((s) => s.toLowerCase()))
      const extra = parts.filter((s) => !have.has(s.toLowerCase()))
      return { ...c, skills: [...c.skills, ...extra] }
    })
  }
  const toggle = (s) => {
    if (cv.skills.includes(s)) update((c) => ({ ...c, skills: c.skills.filter((x) => x !== s) }))
    else add(s)
  }
  return (
    <>
      <Tip>{tips.skills}</Tip>
      <div className="field">
        <label>أضف مهارة</label>
        <form
          className="skill-input"
          onSubmit={(e) => {
            e.preventDefault()
            add(text)
            setText('')
          }}
        >
          <input value={text} dir="auto" onChange={(e) => setText(e.target.value)} placeholder={cv.lang === 'en' ? 'e.g. Financial Analysis' : 'مثال: التحليل المالي'} enterKeyHint="done" />
          <button type="submit" className="btn btn-soft btn-sm" disabled={!text.trim()}>
            <Icon name="plus" size={18} stroke={2.4} /> إضافة
          </button>
        </form>
        <span className="field-hint">يمكنك كتابة أكثر من مهارة مفصولة بفاصلة</span>
      </div>
      <button type="button" className="btn btn-ghost btn-block" style={{ marginBottom: 18 }} onClick={() => setEx(true)}>
        <Icon name="sparkle" size={18} /> مهارات مقترحة حسب مجالك
      </button>
      <div className="section-label">
        <span>مهاراتك ({cv.skills.length})</span>
      </div>
      {cv.skills.length ? (
        <div className="chips">
          {cv.skills.map((s) => (
            <button key={s} type="button" className="chip-btn on" onClick={() => toggle(s)} aria-label={`حذف ${s}`}>
              {s}
              <Icon name="close" size={14} stroke={2.4} />
            </button>
          ))}
        </div>
      ) : (
        <p className="empty-note">لم تضف مهارات بعد</p>
      )}
      <PhraseSheet open={ex} onClose={() => setEx(false)} lang={cv.lang} kind="skills" used={cv.skills} onPick={toggle} />
    </>
  )
}

// ───────── الأقسام اللي فيها عناصر ─────────
const LIST_META = {
  experience: {
    add: 'إضافة وظيفة',
    title: (x) => x.role || x.company || 'وظيفة جديدة',
    sub: (x, lang) => [x.company, fmtRange(x, lang)].filter(Boolean).join(' · '),
  },
  education: {
    add: 'إضافة مؤهل',
    title: (x) => x.degree || x.school || 'مؤهل جديد',
    sub: (x, lang) => [x.school, fmtRange(x, lang)].filter(Boolean).join(' · '),
  },
  languages: {
    add: 'إضافة لغة',
    title: (x) => x.name || 'لغة جديدة',
    sub: (x) => LEVELS.find((l) => l.id === x.level)?.ar || '',
  },
  courses: {
    add: 'إضافة دورة أو شهادة',
    title: (x) => x.name || 'دورة جديدة',
    sub: (x) => [x.org, x.year].filter(Boolean).join(' · '),
  },
  projects: {
    add: 'إضافة مشروع',
    title: (x) => x.name || 'مشروع جديد',
    sub: (x) => x.link || '',
  },
}

const LANG_CHIPS = {
  ar: ['العربية', 'الإنجليزية', 'الفرنسية', 'الألمانية', 'الإسبانية', 'التركية'],
  en: ['Arabic', 'English', 'French', 'German', 'Spanish', 'Turkish'],
}

function ItemForm({ kind, item, set, lang, onExamples }) {
  const en = lang === 'en'
  switch (kind) {
    case 'experience':
      return (
        <>
          <Field label="المسمى الوظيفي" value={item.role} onChange={set('role')} dir="auto" placeholder={en ? 'Sales Manager' : 'مثال: مدير مبيعات'} />
          <Field label="الشركة أو الجهة" value={item.company} onChange={set('company')} dir="auto" />
          <Field label="المدينة (اختياري)" value={item.location} onChange={set('location')} dir="auto" />
          <DatePick label="تاريخ البداية" value={item.start} onChange={set('start')} />
          <label className="check-row">
            <input type="checkbox" checked={item.current} onChange={(e) => set('current')(e.target.checked)} />
            أعمل هنا حاليًا
          </label>
          {!item.current ? <DatePick label="تاريخ الانتهاء" value={item.end} onChange={set('end')} /> : null}
          <TextArea
            label="الإنجازات والمهام"
            value={item.bullets}
            rows={5}
            dir="auto"
            onChange={set('bullets')}
            hint="كل سطر = نقطة مستقلة في السيرة"
            placeholder={en ? 'Increased monthly sales by 20%…' : 'مثال: زيادة المبيعات الشهرية بنسبة 20%…'}
            tools={
              <button type="button" className="examples-btn" onClick={onExamples}>
                <Icon name="sparkle" size={14} /> أمثلة جاهزة
              </button>
            }
          />
        </>
      )
    case 'education':
      return (
        <>
          <Field label="المؤهل أو الدرجة" value={item.degree} onChange={set('degree')} dir="auto" placeholder={en ? 'B.Sc. in Accounting' : 'مثال: بكالوريوس تجارة – محاسبة'} />
          <Field label="الجامعة أو المدرسة" value={item.school} onChange={set('school')} dir="auto" />
          <Field label="المدينة (اختياري)" value={item.location} onChange={set('location')} dir="auto" />
          <DatePick label="تاريخ البداية" value={item.start} onChange={set('start')} />
          <label className="check-row">
            <input type="checkbox" checked={item.current} onChange={(e) => set('current')(e.target.checked)} />
            أدرس حاليًا
          </label>
          {!item.current ? <DatePick label="تاريخ التخرج" value={item.end} onChange={set('end')} /> : null}
          <TextArea label="تفاصيل (اختياري)" value={item.details} rows={2} dir="auto" onChange={set('details')} placeholder={en ? 'GPA 3.6/4 · Graduation project: …' : 'مثال: التقدير جيد جدًا · مشروع التخرج: …'} />
        </>
      )
    case 'languages':
      return (
        <>
          <Field label="اللغة" value={item.name} onChange={set('name')} dir="auto" />
          <div className="chips" style={{ marginTop: -6, marginBottom: 14 }}>
            {LANG_CHIPS[lang].map((n) => (
              <button key={n} type="button" className={`chip-btn ${item.name === n ? 'on' : ''}`} onClick={() => set('name')(n)}>
                {n}
              </button>
            ))}
          </div>
          <div className="field">
            <label>المستوى</label>
            <Segmented className="wrap" value={item.level} onChange={set('level')} options={LEVELS.map((l) => ({ value: l.id, label: l.ar }))} />
          </div>
        </>
      )
    case 'courses':
      return (
        <>
          <Field label="اسم الدورة أو الشهادة" value={item.name} onChange={set('name')} dir="auto" placeholder={en ? 'Google Data Analytics Certificate' : 'مثال: شهادة CMA'} />
          <div className="grid2">
            <Field label="الجهة المانحة" value={item.org} onChange={set('org')} dir="auto" />
            <Field label="السنة" value={item.year} onChange={(v) => set('year')(v.replace(/[^\d٠-٩\-–/ ]/g, '').slice(0, 11))} inputMode="numeric" dir="ltr" placeholder="2024" />
          </div>
        </>
      )
    case 'projects':
      return (
        <>
          <Field label="اسم المشروع" value={item.name} onChange={set('name')} dir="auto" />
          <Field label="رابط (اختياري)" value={item.link} onChange={set('link')} dir="ltr" inputMode="url" placeholder="github.com/you/project" />
          <TextArea label="وصف قصير" value={item.details} rows={3} dir="auto" onChange={set('details')} hint="دورك، والأدوات، والنتيجة" />
        </>
      )
    default:
      return null
  }
}

function ListSection({ cv, update, kind }) {
  const meta = LIST_META[kind]
  const items = cv[kind]
  const [openId, setOpenId] = useState(() => (items.length === 1 ? items[0].id : null))
  const [delAsk, setDelAsk] = useState(null)
  const [exFor, setExFor] = useState(null)
  const tips = TIPS[cv.lang] || TIPS.ar

  const setItem = (id) => (k) => (v) =>
    update((c) => ({ ...c, [kind]: c[kind].map((x) => (x.id === id ? { ...x, [k]: v } : x)) }))
  const addItem = () => {
    const it = BLANK_ITEM[kind]()
    update((c) => ({ ...c, [kind]: [...c[kind], it] }))
    setOpenId(it.id)
  }
  const move = (i, d) =>
    update((c) => {
      const arr = [...c[kind]]
      const j = i + d
      if (j < 0 || j >= arr.length) return c
      ;[arr[i], arr[j]] = [arr[j], arr[i]]
      return { ...c, [kind]: arr }
    })
  const exItem = items.find((x) => x.id === exFor)

  return (
    <>
      <Tip>{tips[kind]}</Tip>
      <div className="items">
        {items.map((it, i) => {
          const open = openId === it.id
          return (
            <div key={it.id} className="item">
              <button type="button" className="item-head" aria-expanded={open} onClick={() => setOpenId(open ? null : it.id)}>
                <span className="item-num">{i + 1}</span>
                <span className="item-title">
                  <b>{meta.title(it)}</b>
                  {meta.sub(it, 'ar') ? <small>{meta.sub(it, 'ar')}</small> : null}
                </span>
                <Icon name={open ? 'up' : 'down'} size={20} />
              </button>
              {open ? (
                <div className="item-body">
                  <ItemForm kind={kind} item={it} set={setItem(it.id)} lang={cv.lang} onExamples={() => setExFor(it.id)} />
                  <div className="item-tools">
                    <div className="left">
                      <button type="button" className="icon-btn sm" aria-label="تحريك لأعلى" disabled={i === 0} onClick={() => move(i, -1)}>
                        <Icon name="up" size={20} />
                      </button>
                      <button type="button" className="icon-btn sm" aria-label="تحريك لأسفل" disabled={i === items.length - 1} onClick={() => move(i, 1)}>
                        <Icon name="down" size={20} />
                      </button>
                    </div>
                    <button type="button" className="btn btn-sm btn-ghost" style={{ color: 'var(--danger)' }} onClick={() => setDelAsk(it.id)}>
                      <Icon name="trash" size={17} /> حذف
                    </button>
                  </div>
                </div>
              ) : null}
            </div>
          )
        })}
        <button type="button" className="add-btn" onClick={addItem}>
          <Icon name="plus" size={20} stroke={2.2} /> {meta.add}
        </button>
      </div>
      {kind === 'experience' ? (
        <PhraseSheet
          open={!!exItem}
          onClose={() => setExFor(null)}
          lang={cv.lang}
          kind="bullets"
          used={exItem ? bulletLines(exItem.bullets) : []}
          onPick={(t) => {
            if (!exItem) return
            const lines = bulletLines(exItem.bullets)
            const next = lines.includes(t) ? lines.filter((l) => l !== t) : [...lines, t]
            setItem(exItem.id)('bullets')(next.join('\n'))
          }}
        />
      ) : null}
      <Confirm
        open={!!delAsk}
        title="حذف العنصر؟"
        yes="حذف"
        danger
        onYes={() => {
          update((c) => ({ ...c, [kind]: c[kind].filter((x) => x.id !== delAsk) }))
          setDelAsk(null)
        }}
        onNo={() => setDelAsk(null)}
      />
    </>
  )
}

export default function Section({ id, sectionKey }) {
  const [cv, update] = useCv(id)
  if (!cv) return <Screen title="">{null}</Screen>
  const key = sectionKey
  let body
  if (key === 'personal') body = <Personal cv={cv} update={update} />
  else if (key === 'summary') body = <Summary cv={cv} update={update} />
  else if (key === 'skills') body = <Skills cv={cv} update={update} />
  else body = <ListSection cv={cv} update={update} kind={key} />

  return (
    <Screen title={SECTION_NAMES[key]}>
      {body}
      {key !== 'personal' ? (
        <div style={{ marginTop: 24 }}>
          <Toggle
            label="إظهار هذا القسم في السيرة"
            sub={cv.hidden[key] ? 'القسم مخفي الآن ولن يظهر في PDF' : null}
            checked={!cv.hidden[key]}
            onChange={(on) => update((c) => ({ ...c, hidden: { ...c.hidden, [key]: !on } }))}
          />
        </div>
      ) : null}
    </Screen>
  )
}
