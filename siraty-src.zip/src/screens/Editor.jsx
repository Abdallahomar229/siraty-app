import { useMemo, useState } from 'react'
import { useCv } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Icon, SECTION_ICONS } from '../components/Icons.jsx'
import { Ring, Screen, Segmented, Sheet } from '../components/ui.jsx'
import { LABELS, SECTION_KEYS, bulletLines, cvDisplayName, hasContent } from '../cv/model.js'
import { strength } from '../cv/strength.js'

// أسماء الأقسام في الواجهة (عربي دايمًا، بغض النظر عن لغة السيرة)
export const SECTION_NAMES = {
  personal: 'البيانات الشخصية',
  summary: 'الملخص المهني',
  experience: 'الخبرات العملية',
  education: 'التعليم',
  skills: 'المهارات',
  languages: 'اللغات',
  courses: 'الدورات والشهادات',
  projects: 'المشاريع',
}

function count(n, one, two, many) {
  if (n === 1) return one
  if (n === 2) return two
  if (n >= 3 && n <= 10) return `${n} ${many}`
  return `${n} ${one}`
}

function summaryOf(cv, key) {
  switch (key) {
    case 'personal':
      return [cv.personal.fullName, cv.personal.jobTitle].filter(Boolean).join(' · ') || 'الاسم والمسمى ووسائل التواصل'
    case 'summary':
      return cv.summary.trim() ? `${cv.summary.trim().slice(0, 60)}…` : 'نبذة قصيرة عنك في جملتين أو ثلاث'
    case 'experience': {
      const n = cv.experience.filter((x) => x.role || x.company).length
      if (!n) return 'وظائفك وإنجازاتك'
      const b = cv.experience.reduce((s, x) => s + bulletLines(x.bullets).length, 0)
      return `${count(n, 'وظيفة واحدة', 'وظيفتان', 'وظائف')} · ${b} إنجاز`
    }
    case 'education': {
      const n = cv.education.filter((x) => x.degree || x.school).length
      return n ? count(n, 'مؤهل واحد', 'مؤهلان', 'مؤهلات') : 'شهادتك الجامعية أو الدراسية'
    }
    case 'skills':
      return cv.skills.length ? cv.skills.slice(0, 4).join('، ') : 'مهاراتك التقنية والشخصية'
    case 'languages': {
      const l = cv.languages.filter((x) => x.name)
      return l.length ? l.map((x) => x.name).join('، ') : 'اللغات التي تتحدثها'
    }
    case 'courses': {
      const n = cv.courses.filter((x) => x.name).length
      return n ? count(n, 'دورة واحدة', 'دورتان', 'دورات') : 'شهادات ودورات تدريبية'
    }
    case 'projects': {
      const n = cv.projects.filter((x) => x.name).length
      return n ? count(n, 'مشروع واحد', 'مشروعان', 'مشاريع') : 'أعمال ومشاريع تثبت مهاراتك (اختياري)'
    }
    default:
      return ''
  }
}

export default function Editor({ id }) {
  const [cv, update] = useCv(id)
  const nav = useNav()
  const [orderOpen, setOrderOpen] = useState(false)
  const s = useMemo(() => (cv ? strength(cv) : null), [cv])
  if (!cv) return <Screen title="السيرة">{null}</Screen>

  const open = (key) => nav.navigate({ name: 'section', id, key })
  const next = s.todo[0]
  const personalDone = !!cv.personal.fullName && (!!cv.personal.email || !!cv.personal.phone)

  const move = (key, dir) => {
    const o = [...cv.order]
    const i = o.indexOf(key)
    const j = i + dir
    if (j < 0 || j >= o.length) return
    ;[o[i], o[j]] = [o[j], o[i]]
    update({ order: o })
  }

  return (
    <Screen
      title={cvDisplayName(cv)}
      sub={cv.lang === 'en' ? 'سيرة بالإنجليزية' : 'سيرة بالعربية'}
      right={
        <button type="button" className="icon-btn" aria-label="معاينة" onClick={() => nav.navigate({ name: 'preview', id })}>
          <Icon name="eye" />
        </button>
      }
      actions={
        <button type="button" className="btn btn-primary btn-block" onClick={() => nav.navigate({ name: 'preview', id })}>
          <Icon name="download" size={20} stroke={2.1} /> معاينة وتحميل PDF
        </button>
      }
    >
      <div className="card score-card">
        <Ring value={s.score} />
        <div className="score-text">
          <b>قوة السيرة: {s.label}</b>
          {next ? (
            <button type="button" className="score-next" onClick={() => open(next.section)}>
              {next.tip}
              <Icon name="chev" size={15} stroke={2.4} />
            </button>
          ) : (
            <small>سيرتك مكتملة. راجعها في المعاينة ثم حمّلها PDF.</small>
          )}
        </div>
      </div>

      <div className="sec-list">
        <button type="button" className="card sec-row" onClick={() => open('personal')}>
          <span className="sec-icon">{cv.photo ? <img src={cv.photo} alt="" /> : <Icon name="user" />}</span>
          <span className="sec-text">
            <b>{SECTION_NAMES.personal}</b>
            <small>{summaryOf(cv, 'personal')}</small>
          </span>
          <span className={`sec-state ${personalDone ? 'done' : 'empty'}`}>{personalDone ? <Icon name="check" size={14} stroke={3} /> : null}</span>
        </button>
        {cv.order.map((key) => {
          const done = hasContent(cv, key)
          const hidden = !!cv.hidden[key]
          return (
            <button key={key} type="button" className={`card sec-row ${hidden ? 'hidden-sec' : ''}`} onClick={() => open(key)}>
              <span className="sec-icon">
                <Icon name={SECTION_ICONS[key]} />
              </span>
              <span className="sec-text">
                <b>{SECTION_NAMES[key]}</b>
                <small>{hidden ? 'مخفي من السيرة' : summaryOf(cv, key)}</small>
              </span>
              {hidden ? (
                <Icon name="eyeOff" size={20} className="chev" />
              ) : (
                <span className={`sec-state ${done ? 'done' : 'empty'}`}>{done ? <Icon name="check" size={14} stroke={3} /> : null}</span>
              )}
            </button>
          )
        })}
      </div>

      <div className="section-label">
        <span>إعدادات السيرة</span>
      </div>
      <div className="cv-settings">
        <div className="card" style={{ padding: 14 }}>
          <div className="field" style={{ marginBottom: 0 }}>
            <label>لغة السيرة (عناوين الأقسام والتواريخ)</label>
            <Segmented
              value={cv.lang}
              onChange={(lang) => update({ lang })}
              options={[
                { value: 'ar', label: 'العربية' },
                { value: 'en', label: 'English' },
              ]}
            />
          </div>
        </div>
        <button type="button" className="card sec-row" onClick={() => setOrderOpen(true)}>
          <span className="sec-icon">
            <Icon name="sort" />
          </span>
          <span className="sec-text">
            <b>ترتيب الأقسام</b>
            <small>قدّم الأهم لك (مثلًا: التعليم قبل الخبرات لحديثي التخرج)</small>
          </span>
          <Icon name="chev" size={18} className="chev" />
        </button>
      </div>

      <Sheet open={orderOpen} onClose={() => setOrderOpen(false)} title="ترتيب الأقسام">
        <div className="menu-list">
          {cv.order.map((key, i) => (
            <div key={key} className="menu-item">
              <Icon name={SECTION_ICONS[key]} />
              <span style={{ flex: 1 }}>
                {SECTION_NAMES[key]}
                <small style={{ display: 'block', color: 'var(--ink-3)', fontSize: 12 }}>{LABELS[cv.lang][key]}</small>
              </span>
              <button type="button" className="icon-btn sm" aria-label="لأعلى" disabled={i === 0} onClick={() => move(key, -1)}>
                <Icon name="up" size={20} />
              </button>
              <button type="button" className="icon-btn sm" aria-label="لأسفل" disabled={i === cv.order.length - 1} onClick={() => move(key, 1)}>
                <Icon name="down" size={20} />
              </button>
            </div>
          ))}
        </div>
        <p className="field-hint" style={{ marginTop: 10 }}>
          في القوالب ذات العمودين تظهر المهارات واللغات في العمود الجانبي.
        </p>
      </Sheet>
    </Screen>
  )
}

export { SECTION_KEYS }
