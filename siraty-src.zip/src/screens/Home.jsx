import { useMemo, useState } from 'react'
import { useApp } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Icon } from '../components/Icons.jsx'
import { Confirm, Field, Sheet } from '../components/ui.jsx'
import { CvThumb } from '../components/CvView.jsx'
import { cvDisplayName, sampleCv } from '../cv/model.js'
import logo from '../assets/logo.png'

function ago(t) {
  const m = Math.round((Date.now() - t) / 60000)
  if (m < 1) return 'الآن'
  if (m < 60) return m <= 2 ? 'منذ دقيقة' : `منذ ${m} دقيقة`
  const h = Math.round(m / 60)
  if (h < 24) return h <= 1 ? 'منذ ساعة' : `منذ ${h} ساعات`
  const d = Math.round(h / 24)
  if (d <= 1) return 'أمس'
  if (d < 30) return `منذ ${d} يومًا`
  return new Date(t).toLocaleDateString('ar-EG-u-nu-latn', { day: 'numeric', month: 'long', year: 'numeric' })
}

export function NewCvSheet({ open, onClose }) {
  const { createCv } = useApp()
  const nav = useNav()
  const [lang, setLang] = useState('ar')
  const go = (fromSample) => {
    const id = createCv(lang, fromSample)
    onClose()
    nav.navigate({ name: 'editor', id })
  }
  return (
    <Sheet open={open} onClose={onClose} title="سيرة ذاتية جديدة">
      <p className="field-hint" style={{ marginBottom: 10 }}>
        بأي لغة ستكتب سيرتك؟ (يمكنك تغييرها لاحقًا)
      </p>
      <div className="lang-pick">
        <button type="button" className={`lang-opt ${lang === 'ar' ? 'on' : ''}`} onClick={() => setLang('ar')}>
          <span className="glyph">ع</span>
          <b>عربي</b>
          <small>للشركات العربية والحكومية</small>
        </button>
        <button type="button" className={`lang-opt ${lang === 'en' ? 'on' : ''}`} onClick={() => setLang('en')}>
          <span className="glyph">En</span>
          <b>English</b>
          <small>للشركات الدولية و LinkedIn</small>
        </button>
      </div>
      <div className="row-btns">
        <button type="button" className="btn btn-primary" onClick={() => go(false)}>
          <Icon name="edit" size={20} /> ابدأ من صفحة فارغة
        </button>
        <button type="button" className="btn btn-ghost" onClick={() => go(true)}>
          <Icon name="sparkle" size={20} /> ابدأ من مثال جاهز وعدّل عليه
        </button>
      </div>
    </Sheet>
  )
}

export default function Home() {
  const { cvs, plus, deleteCv, duplicateCv, updateCv, toast } = useApp()
  const nav = useNav()
  const [newOpen, setNewOpen] = useState(false)
  const [menu, setMenu] = useState(null)
  const [renaming, setRenaming] = useState(null)
  const [delAsk, setDelAsk] = useState(null)

  const demo = useMemo(() => {
    const a = sampleCv('ar')
    const b = { ...sampleCv('en'), template: 'modern', color: 'teal' }
    const c = { ...sampleCv('ar'), template: 'band', color: 'navy' }
    a.template = 'classic'
    return [a, b, c]
  }, [])

  const menuCv = cvs.find((c) => c.id === menu)

  return (
    <div className="screen home">
      <header className="topbar">
        <div className="brand-row">
          <img className="logo" src={logo} alt="" />
          <span className="brand-name">سيرتي</span>
        </div>
        {!plus ? (
          <button type="button" className="plus-pill" onClick={() => nav.navigate({ name: 'paywall', reason: 'home' })}>
            <Icon name="crown" size={15} stroke={2.2} /> بلس
          </button>
        ) : null}
        <button type="button" className="icon-btn" aria-label="الإعدادات" onClick={() => nav.navigate({ name: 'settings' })}>
          <Icon name="gear" />
        </button>
      </header>

      <main className="screen-body">
        {cvs.length === 0 ? (
          <section className="hero">
            <h2>سيرتك الذاتية جاهزة في دقائق</h2>
            <p>قوالب احترافية بالعربي والإنجليزي، وأمثلة جاهزة لكل مجال، وملف PDF جاهز للإرسال فورًا.</p>
            <div className="hero-stack" aria-hidden="true">
              {demo.map((cv) => (
                <CvThumb key={cv.template} cv={cv} plus />
              ))}
            </div>
            <div className="hero-btns">
              <button type="button" className="btn btn-primary btn-block" onClick={() => setNewOpen(true)}>
                <Icon name="plus" size={20} stroke={2.2} /> أنشئ سيرتك الآن
              </button>
            </div>
            <div className="hero-feats">
              <span>
                <Icon name="check" size={15} stroke={2.6} /> متوافقة مع أنظمة ATS
              </span>
              <span>
                <Icon name="check" size={15} stroke={2.6} /> بدون إنترنت
              </span>
              <span>
                <Icon name="check" size={15} stroke={2.6} /> بياناتك على جهازك فقط
              </span>
            </div>
          </section>
        ) : (
          <>
            <div className="section-label">
              <span>سيرك الذاتية ({cvs.length})</span>
            </div>
            <div className="cv-grid">
              {cvs.map((cv) => (
                <div key={cv.id} className="cv-card">
                  <button type="button" className="thumb-box" aria-label={`فتح ${cvDisplayName(cv)}`} onClick={() => nav.navigate({ name: 'editor', id: cv.id })}>
                    <CvThumb cv={cv} plus={plus} />
                  </button>
                  <div className="cv-card-info">
                    <div className="cv-card-text">
                      <strong>{cvDisplayName(cv)}</strong>
                      <small>
                        <span className="lang-tag">{cv.lang === 'en' ? 'EN' : 'ع'}</span>
                        {ago(cv.updatedAt)}
                      </small>
                    </div>
                    <button type="button" className="icon-btn sm more" aria-label="خيارات" onClick={() => setMenu(cv.id)}>
                      <Icon name="more" size={20} />
                    </button>
                  </div>
                </div>
              ))}
              <button type="button" className="new-card" onClick={() => setNewOpen(true)}>
                <span className="plus-circle">
                  <Icon name="plus" size={24} stroke={2.2} />
                </span>
                سيرة جديدة
              </button>
            </div>
          </>
        )}
      </main>

      <NewCvSheet open={newOpen} onClose={() => setNewOpen(false)} />

      <Sheet open={!!menuCv} onClose={() => setMenu(null)} title={menuCv ? cvDisplayName(menuCv) : ''}>
        <div className="menu-list">
          <button type="button" className="menu-item" onClick={() => { setMenu(null); nav.navigate({ name: 'editor', id: menu }) }}>
            <Icon name="edit" /> تعديل
          </button>
          <button type="button" className="menu-item" onClick={() => { setMenu(null); nav.navigate({ name: 'preview', id: menu }) }}>
            <Icon name="download" /> معاينة وتحميل PDF
          </button>
          <button type="button" className="menu-item" onClick={() => { setRenaming({ id: menu, value: menuCv?.title || '' }); setMenu(null) }}>
            <Icon name="type" /> إعادة التسمية
          </button>
          <button type="button" className="menu-item" onClick={() => { duplicateCv(menu); setMenu(null); toast('تم إنشاء نسخة') }}>
            <Icon name="copy" /> نسخة مكررة
          </button>
          <button type="button" className="menu-item danger" onClick={() => { setDelAsk(menu); setMenu(null) }}>
            <Icon name="trash" /> حذف
          </button>
        </div>
      </Sheet>

      <Sheet
        open={!!renaming}
        onClose={() => setRenaming(null)}
        title="اسم السيرة"
        footer={
          <button
            type="button"
            className="btn btn-primary btn-block"
            onClick={() => {
              updateCv(renaming.id, { title: renaming.value.trim() })
              setRenaming(null)
            }}
          >
            حفظ
          </button>
        }
      >
        {renaming ? (
          <Field
            label="اسم يظهر لك فقط (مثلًا: سيرة شركات البترول)"
            value={renaming.value}
            maxLength={60}
            onChange={(v) => setRenaming((r) => ({ ...r, value: v }))}
          />
        ) : null}
      </Sheet>

      <Confirm
        open={!!delAsk}
        title="حذف السيرة؟"
        text="سيتم حذف السيرة من جهازك نهائيًا، ولا يمكن استرجاعها."
        yes="حذف"
        danger
        onYes={() => {
          deleteCv(delAsk)
          setDelAsk(null)
          toast('تم الحذف')
        }}
        onNo={() => setDelAsk(null)}
      />
    </div>
  )
}
