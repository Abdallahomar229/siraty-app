import { useRef, useState } from 'react'
import { useApp } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Confirm, Screen, Sheet, Toggle } from '../components/ui.jsx'
import { Icon } from '../components/Icons.jsx'
import { SHOW_TEST_MODE, APP_VERSION, REVIEW_UNLOCK, SUPPORT_EMAIL } from '../lib/config.js'
import { redeemReviewCode, REVIEW_TAPS } from '../lib/review.js'
import { restore } from '../lib/billing.js'

function untilText(ts) {
  try {
    return new Date(ts).toLocaleDateString('ar-EG-u-nu-latn', { day: 'numeric', month: 'long' })
  } catch {
    return ''
  }
}

export default function Settings() {
  const { settings, setSetting, resetAll, toast, plus, entitled, reviewPlus, reviewUntil, setReviewUntil, refreshEntitlement } = useApp()
  const nav = useNav()
  const [askReset, setAskReset] = useState(false)
  const [askCode, setAskCode] = useState(false)
  const [code, setCode] = useState('')
  const [checking, setChecking] = useState(false)
  const taps = useRef({ n: 0, t: 0 })

  // ٧ دوسات ورا بعض على «الإصدار» بتفتح خانة كود المراجعة (لمراجعي Google Play)
  const onVersionTap = () => {
    if (!REVIEW_UNLOCK) return
    const now = Date.now()
    const r = taps.current
    r.n = now - r.t < 1500 ? r.n + 1 : 1
    r.t = now
    if (r.n >= REVIEW_TAPS) {
      r.n = 0
      setCode('')
      setAskCode(true)
    }
  }

  const submitCode = async (e) => {
    e.preventDefault()
    if (checking) return
    setChecking(true)
    try {
      const res = await redeemReviewCode(code)
      if (res.ok) {
        setReviewUntil(res.until)
        setAskCode(false)
        toast('تم فتح «بلس» للمراجعة لمدة 7 أيام')
      } else if (res.reason === 'unsupported') toast('هذه الخاصية غير متاحة على هذا الجهاز')
      else toast('الكود غير صحيح')
    } finally {
      setChecking(false)
    }
  }

  const doRestore = async () => {
    const res = await restore()
    refreshEntitlement()
    if (res?.ok) toast(res.entitled ? 'تم استرجاع اشتراكك في «بلس»' : 'لا توجد مشتريات على هذا الحساب')
    else toast(res?.message || 'تعذّر استرجاع المشتريات الآن')
  }

  return (
    <Screen title="الإعدادات">
      <div className="set-group">
        <button type="button" className="plus-card" onClick={() => nav.navigate({ name: 'paywall', reason: 'settings' })}>
          <span className="pay-crown">
            <Icon name="crown" size={24} stroke={2} />
          </span>
          <span style={{ flex: 1 }}>
            <b>{entitled ? '«سيرتي بلس» مفعّل' : 'سيرتي بلس'}</b>
            <small>{entitled ? 'شكرًا لدعمك! كل القوالب مفتوحة.' : 'كل القوالب، بدون علامة مائية، بدون إعلانات'}</small>
          </span>
          <Icon name="chev" size={18} />
        </button>
        {reviewPlus && !entitled ? <p className="field-hint" style={{ margin: '8px 4px 0' }}>كود المراجعة مفعّل حتى {untilText(reviewUntil)}.</p> : null}
      </div>

      {SHOW_TEST_MODE ? (
        <div className="set-group">
          <Toggle
            label="وضع التجربة: فتح «بلس»"
            sub="للمعاينة فقط — غير موجود في نسخة المتجر"
            checked={settings.testPlus}
            onChange={(v) => setSetting('testPlus', v)}
          />
        </div>
      ) : null}

      <div className="set-group menu-list">
        <button type="button" className="menu-item" onClick={doRestore}>
          <Icon name="refresh" /> استرجاع المشتريات
        </button>
        <a className="menu-item" href={`mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent('سيرتي — ملاحظة')}`} style={{ color: 'inherit', textDecoration: 'none' }}>
          <Icon name="mail" /> راسلنا (اقتراح أو مشكلة)
        </a>
        <button type="button" className="menu-item" onClick={() => nav.navigate({ name: 'privacy' })}>
          <Icon name="shield" /> سياسة الخصوصية
        </button>
        <button type="button" className="menu-item danger" onClick={() => setAskReset(true)}>
          <Icon name="trash" /> حذف كل السير من الجهاز
        </button>
      </div>

      <button type="button" className="version" onClick={onVersionTap}>
        الإصدار {APP_VERSION}
        {plus ? ' · بلس' : ''}
      </button>

      <Confirm
        open={askReset}
        title="حذف كل البيانات؟"
        text="سيتم حذف كل السير الذاتية المحفوظة على هذا الجهاز نهائيًا. اشتراكك في «بلس» لن يتأثر."
        yes="حذف الكل"
        danger
        onYes={() => {
          resetAll()
          setAskReset(false)
          toast('تم حذف كل البيانات')
        }}
        onNo={() => setAskReset(false)}
      />

      <Sheet open={askCode} title="كود المراجعة" onClose={() => setAskCode(false)}>
        <form onSubmit={submitCode}>
          <p className="confirm-text" style={{ marginBottom: 12 }}>
            اكتب الكود لفتح «بلس».
            <span lang="en" dir="ltr" style={{ display: 'block' }}>
              Enter your review code to unlock Siraty Plus.
            </span>
          </p>
          <div className="field">
            <input
              dir="ltr"
              lang="en"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Review code"
              aria-label="كود المراجعة"
              autoComplete="off"
              autoCapitalize="characters"
              autoCorrect="off"
              spellCheck={false}
              maxLength={40}
            />
          </div>
          <button type="submit" className="btn btn-primary btn-block" disabled={checking || !code.trim()}>
            تفعيل
          </button>
        </form>
      </Sheet>
    </Screen>
  )
}
