// المعاينة: القالب واللون والخط + تحميل PDF
import { useEffect, useRef, useState } from 'react'
import { useApp, useCv } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Icon } from '../components/Icons.jsx'
import { PlusBadge, Screen, Sheet } from '../components/ui.jsx'
import { CvPreview } from '../components/CvView.jsx'
import { COLORS, FONTS, TEMPLATES, colorOf, fontOf, getTemplate } from '../cv/templates.js'
import { fileName } from '../cv/model.js'
import { isNativeApp, nativePdf, nativePlatform, preloadAd, showInterstitial } from '../lib/native.js'
import { load, save } from '../lib/storage.js'
import { TPL_IMG } from '../content/tplImages.js'

const AD_GAP = 3 * 60 * 1000 // إعلان واحد بالكتير كل ٣ دقايق

function pagesWord(n) {
  if (n === 1) return 'صفحة واحدة'
  if (n === 2) return 'صفحتان'
  return `${n} صفحات`
}

// بيحط نسخة من الصفحات في #print-root (الطباعة بتشوف ده بس)
function stagePrint(docEl) {
  const root = document.getElementById('print-root')
  if (!root || !docEl) return false
  root.innerHTML = ''
  const pages = docEl.querySelectorAll('.preview-doc > .cv-page[data-page]')
  pages.forEach((p) => root.appendChild(p.cloneNode(true)))
  return pages.length > 0
}

function clearPrint() {
  const root = document.getElementById('print-root')
  if (root) root.innerHTML = ''
}

export default function Preview({ id }) {
  const [cv, update] = useCv(id)
  const { plus, toast } = useApp()
  const nav = useNav()
  const [tab, setTab] = useState('tpl')
  const [count, setCount] = useState(1)
  const [busy, setBusy] = useState(false)
  const [more, setMore] = useState(false)
  const docRef = useRef(null)

  useEffect(() => {
    if (!plus) preloadAd()
  }, [plus])
  useEffect(() => clearPrint, [])

  if (!cv) return <Screen title="المعاينة">{null}</Screen>
  const tpl = getTemplate(cv.template)
  const color = colorOf(cv, tpl)
  const font = fontOf(cv, tpl)
  const locked = tpl.plus && !plus

  const exportPdf = async (action = 'share') => {
    if (busy) return
    if (locked) {
      nav.navigate({ name: 'paywall', reason: 'template' })
      return
    }
    setBusy(true)
    try {
      try {
        await document.fonts?.ready
      } catch {
        /* تجاهل */
      }
      if (!plus && isNativeApp()) {
        const last = Number(load('lastAd', 0))
        if (Date.now() - last > AD_GAP) {
          const shown = await showInterstitial()
          if (shown) save('lastAd', Date.now())
        }
      }
      if (!stagePrint(docRef.current)) {
        toast('انتظر لحظة حتى تكتمل المعاينة')
        return
      }
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)))
      if (isNativeApp()) {
        const res = await nativePdf(action, fileName(cv))
        if (res?.ok) {
          if (res.saved) toast('تم حفظ الملف')
        } else if (res?.reason !== 'cancel') {
          toast('تعذّر إنشاء الملف، حاول مرة أخرى')
        }
      } else {
        window.print()
      }
    } finally {
      setBusy(false)
      setTimeout(clearPrint, 1500)
      if (!plus) preloadAd()
    }
  }

  const pickTpl = (t) => {
    update({ template: t.id, color: '', font: '' })
  }

  return (
    <Screen
      className="preview"
      title="المعاينة"
      sub={pagesWord(count)}
      right={
        <button type="button" className="icon-btn" aria-label="تعديل" onClick={() => nav.navigate({ name: 'editor', id })}>
          <Icon name="edit" />
        </button>
      }
      actions={
        <div className="dock">
          <div className="dock-tabs" role="tablist">
            <button type="button" role="tab" aria-selected={tab === 'tpl'} className={tab === 'tpl' ? 'on' : ''} onClick={() => setTab('tpl')}>
              <Icon name="layout" size={18} /> القالب
            </button>
            <button type="button" role="tab" aria-selected={tab === 'color'} className={tab === 'color' ? 'on' : ''} onClick={() => setTab('color')}>
              <Icon name="palette" size={18} /> اللون
            </button>
            <button type="button" role="tab" aria-selected={tab === 'font'} className={tab === 'font' ? 'on' : ''} onClick={() => setTab('font')}>
              <Icon name="type" size={18} /> الخط
            </button>
          </div>
          <div className="dock-panel">
            {tab === 'tpl' ? (
              <div className="tpl-strip">
                {TEMPLATES.map((t) => (
                  <button key={t.id} type="button" className={`tpl-opt ${t.id === tpl.id ? 'on' : ''}`} onClick={() => pickTpl(t)}>
                    <span className="tpl-img">
                      <img src={TPL_IMG[t.id]} alt="" />
                      {t.plus && !plus ? <PlusBadge small /> : null}
                    </span>
                    {t.name}
                  </button>
                ))}
              </div>
            ) : null}
            {tab === 'color' ? (
              <div className="swatches">
                {COLORS.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    className={`swatch ${c.hex === color ? 'on' : ''}`}
                    style={{ background: c.hex }}
                    aria-label={c.id}
                    onClick={() => update({ color: c.id })}
                  >
                    {c.hex === color ? <Icon name="check" size={18} stroke={3} /> : null}
                  </button>
                ))}
              </div>
            ) : null}
            {tab === 'font' ? (
              <div className="font-opts">
                {FONTS.map((f) => (
                  <button key={f.id} type="button" className={`font-opt ${f.id === font.id ? 'on' : ''}`} style={{ fontFamily: `'${f.family}'` }} onClick={() => update({ font: f.id })}>
                    <b>{cv.lang === 'en' ? 'Aa' : 'أبج'}</b>
                    {f.name}
                  </button>
                ))}
              </div>
            ) : null}
          </div>
          <div className="dock-cta">
            {locked ? (
              <button type="button" className="btn btn-gold" style={{ flex: 1 }} onClick={() => nav.navigate({ name: 'paywall', reason: 'template' })}>
                <Icon name="crown" size={19} stroke={2.2} /> افتح قالب «{tpl.name}» مع بلس
              </button>
            ) : (
              <button type="button" className="btn btn-primary" disabled={busy} onClick={() => exportPdf('share')}>
                <Icon name="download" size={20} stroke={2.1} /> {busy ? 'جارٍ التجهيز…' : 'تحميل PDF'}
              </button>
            )}
            <button type="button" className="btn btn-ghost" aria-label="خيارات أخرى" onClick={() => setMore(true)}>
              <Icon name="more" />
            </button>
          </div>
        </div>
      }
    >
      <CvPreview cv={cv} plus={plus} docRef={docRef} onLayout={(l) => setCount(l.count)} />
      {!plus ? (
        <p className="page-count">
          النسخة المجانية تضيف سطرًا صغيرًا «صُمّمت بتطبيق سيرتي» أسفل السيرة.{' '}
          <button type="button" className="link" style={{ fontSize: 12.5, padding: 0 }} onClick={() => nav.navigate({ name: 'paywall', reason: 'watermark' })}>
            إزالته
          </button>
        </p>
      ) : null}

      <Sheet open={more} onClose={() => setMore(false)} title="خيارات أخرى">
        <div className="menu-list">
          <button
            type="button"
            className="menu-item"
            onClick={() => {
              setMore(false)
              exportPdf('print')
            }}
          >
            <Icon name="print" />
            {nativePlatform() === 'ios' ? 'طباعة' : 'طباعة أو حفظ في الملفات'}
          </button>
          <button
            type="button"
            className="menu-item"
            onClick={() => {
              setMore(false)
              nav.navigate({ name: 'editor', id })
            }}
          >
            <Icon name="edit" /> تعديل المحتوى
          </button>
        </div>
      </Sheet>
    </Screen>
  )
}
