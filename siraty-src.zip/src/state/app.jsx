// حالة التطبيق: السير الذاتية (محفوظة على الموبايل بس) + «بلس» + الرسائل السريعة
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { load, save, clearAll } from '../lib/storage.js'
import * as billing from '../lib/billing.js'
import { loadReviewUntil, keepReview } from '../lib/review.js'
import { SHOW_TEST_MODE } from '../lib/config.js'
import { blankCv, normalize, sampleCv, uid } from '../cv/model.js'

const DEFAULT_SETTINGS = { testPlus: false }
const AppCtx = createContext(null)

function loadCvs() {
  const list = load('cvs', [])
  return Array.isArray(list) ? list.map(normalize) : []
}

export function AppProvider({ children }) {
  const [cvs, setCvs] = useState(loadCvs)
  const [settings, setSettings] = useState(() => ({ ...DEFAULT_SETTINGS, ...load('settings', {}) }))
  const [entitled, setEntitled] = useState(() => billing.isPlus())
  const [reviewUntil, setReviewUntil] = useState(loadReviewUntil)
  const [toastState, setToastState] = useState(null)
  const saveTimer = useRef(null)
  const latest = useRef(cvs)
  latest.current = cvs

  // الحفظ بعد ما الكتابة تهدى شوية (ومع الخروج من التطبيق فورًا)
  useEffect(() => {
    clearTimeout(saveTimer.current)
    saveTimer.current = setTimeout(() => {
      if (!save('cvs', cvs)) setToastState({ msg: 'مساحة التخزين ممتلئة — احذف صورة أو سيرة قديمة', id: Date.now() })
    }, 350)
  }, [cvs])
  useEffect(() => {
    const flush = () => save('cvs', latest.current)
    const onVis = () => document.visibilityState === 'hidden' && flush()
    window.addEventListener('pagehide', flush)
    document.addEventListener('visibilitychange', onVis)
    return () => {
      window.removeEventListener('pagehide', flush)
      document.removeEventListener('visibilitychange', onVis)
    }
  }, [])

  useEffect(() => {
    save('settings', settings)
  }, [settings])

  useEffect(() => {
    if (!toastState) return undefined
    const t = setTimeout(() => setToastState(null), 2800)
    return () => clearTimeout(t)
  }, [toastState])

  useEffect(() => {
    const onEnt = () => setEntitled(billing.isPlus())
    window.addEventListener('siraty:entitlement', onEnt)
    return () => window.removeEventListener('siraty:entitlement', onEnt)
  }, [])

  const toast = useCallback((msg) => setToastState({ msg, id: Date.now() }), [])
  const setSetting = useCallback((key, value) => setSettings((s) => ({ ...s, [key]: value })), [])
  const refreshEntitlement = useCallback(() => setEntitled(billing.isPlus()), [])

  const createCv = useCallback((lang, fromSample = false) => {
    const cv = fromSample ? sampleCv(lang) : blankCv(lang)
    cv.id = uid('cv')
    cv.createdAt = cv.updatedAt = Date.now()
    setCvs((list) => [cv, ...list])
    return cv.id
  }, [])

  // patch: كائن بالحقول الجديدة أو دالة (cv) => cv
  const updateCv = useCallback((id, patch) => {
    setCvs((list) =>
      list.map((cv) => {
        if (cv.id !== id) return cv
        const next = typeof patch === 'function' ? patch(cv) : { ...cv, ...patch }
        return { ...next, updatedAt: Date.now() }
      }),
    )
  }, [])

  const deleteCv = useCallback((id) => setCvs((list) => list.filter((cv) => cv.id !== id)), [])

  const duplicateCv = useCallback((id) => {
    const src = latest.current.find((c) => c.id === id)
    if (!src) return null
    const copy = normalize({ ...JSON.parse(JSON.stringify(src)), id: uid('cv'), createdAt: Date.now(), updatedAt: Date.now() })
    copy.title = `${src.title || src.personal.fullName || 'سيرة'} (نسخة)`
    setCvs((list) => [copy, ...list])
    return copy.id
  }, [])

  const resetAll = useCallback(() => {
    const had = billing.isPlus()
    const review = loadReviewUntil()
    clearAll()
    billing.keepEntitlement(had)
    keepReview(review)
    setCvs([])
    setSettings({ ...DEFAULT_SETTINGS })
    setEntitled(had)
  }, [])

  const reviewPlus = reviewUntil > Date.now()
  const plus = entitled || reviewPlus || (SHOW_TEST_MODE && !!settings.testPlus)

  const value = useMemo(
    () => ({
      cvs,
      createCv,
      updateCv,
      deleteCv,
      duplicateCv,
      settings,
      setSetting,
      plus,
      entitled,
      refreshEntitlement,
      reviewPlus,
      reviewUntil,
      setReviewUntil,
      toast,
      toastState,
      resetAll,
    }),
    [cvs, createCv, updateCv, deleteCv, duplicateCv, settings, setSetting, plus, entitled, refreshEntitlement, reviewPlus, reviewUntil, toast, toastState, resetAll],
  )
  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>
}

export function useApp() {
  return useContext(AppCtx)
}

export function useCv(id) {
  const { cvs, updateCv } = useApp()
  const cv = cvs.find((c) => c.id === id) || null
  const update = useCallback((patch) => updateCv(id, patch), [id, updateCv])
  return [cv, update]
}
