import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { viteSingleFile } from 'vite-plugin-singlefile'

// npm run build        → dist/        (ملفات التطبيق للمتجر)
// npm run build:single → dist-single/ (ملف HTML واحد للمعاينة)
// رقم الإصدار اللي بيظهر في الإعدادات: في GitHub Actions بيطابق versionName = 1.0.<رقم البناء>
if (!process.env.VITE_APP_VERSION && process.env.GITHUB_RUN_NUMBER) {
  process.env.VITE_APP_VERSION = `1.0.${process.env.GITHUB_RUN_NUMBER}`
}

export default defineConfig(({ mode }) => {
  const single = mode === 'single'
  return {
    base: './',
    plugins: [react(), ...(single ? [viteSingleFile({ removeViteModuleLoader: true })] : [])],
    build: {
      outDir: single ? 'dist-single' : 'dist',
      emptyOutDir: true,
      assetsInlineLimit: single ? 100_000_000 : 4096,
      chunkSizeWarningLimit: 1500,
    },
  }
})
