package com.siraty.cv;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

/**
 * إعلانات AdMob بملء الشاشة بين الجولات — النسخة المجانية بس (اللعبة هي اللي بتقرر تطلبها ولا لأ).
 * المعرّفات بتيجي من البناء (ADMOB_APP_ID / ADMOB_INTERSTITIAL)، والافتراضي إعلانات جوجل التجريبية.
 */
final class AdsBridge {
    final MainActivity act;
    InterstitialAd ad;
    boolean loading;
    boolean started;

    AdsBridge(MainActivity act) {
        this.act = act;
    }

    /** إعلانات جوجل التجريبية مبتظهرش للناس في نسخة المتجر — لحد ما نحط معرّفات AdMob الحقيقية */
    static boolean enabled() {
        return BuildConfig.DEBUG || !BuildConfig.ADMOB_INTERSTITIAL.startsWith("ca-app-pub-3940256099942544");
    }

    void start() {
        if (started || !enabled()) return;
        started = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    MobileAds.initialize(act, status -> act.runOnUiThread(AdsBridge.this::load));
                } catch (Throwable t) {
                    started = false;
                }
            }
        }).start();
    }

    void load() {
        if (!enabled() || ad != null || loading || act.isFinishing()) return;
        loading = true;
        try {
            InterstitialAd.load(act, BuildConfig.ADMOB_INTERSTITIAL, new AdRequest.Builder().build(),
                    new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(InterstitialAd a) {
                            ad = a;
                            loading = false;
                        }

                        @Override
                        public void onAdFailedToLoad(LoadAdError e) {
                            ad = null;
                            loading = false;
                        }
                    });
        } catch (Throwable t) {
            loading = false;
        }
    }

    void show() {
        InterstitialAd a = ad;
        if (a == null) {
            act.adDone(false);
            start();
            load();
            return;
        }
        ad = null;
        a.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() {
                act.adDone(true);
                load();
            }

            @Override
            public void onAdFailedToShowFullScreenContent(AdError e) {
                act.adDone(false);
                load();
            }
        });
        try {
            a.show(act);
        } catch (Throwable t) {
            act.adDone(false);
        }
    }
}
