package com.siraty.cv;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.print.SirPdfWriter;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * «سيرتي» — غلاف أندرويد بسيط:
 * WebView بيعرض التطبيق من ملفاته (من غير إنترنت) على عنوان https داخلي،
 * وجسر للجافاسكريبت (SiratyNative): PDF (حفظ/مشاركة/طباعة)، اختيار صورة، «بلس»، الإعلانات، والاهتزاز.
 */
public class MainActivity extends Activity {

    static final String HOST = "appassets.androidplatform.net";
    static final String START_URL = "https://" + HOST + "/index.html";
    static final int PAPER = 0xFFF4F1EC;
    static final int REQ_FILE = 41;

    WebView web;
    BillingBridge billing;
    AdsBridge ads;
    ValueCallback<Uri[]> fileCallback;
    boolean pdfBusy;
    final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(PAPER);
        web = new WebView(this);
        web.setBackgroundColor(PAPER);
        root.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        if (Build.VERSION.SDK_INT >= 30) {
            Api30.edgeToEdge(w, root);
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setWebViewClient(new LocalClient());
        web.setWebChromeClient(new Chrome());
        web.addJavascriptInterface(new Bridge(), "SiratyNative");

        billing = new BillingBridge(this);
        ads = new AdsBridge(this);
        if (Build.VERSION.SDK_INT >= 33) {
            Api33.registerBack(this);
        }

        if (state != null) {
            web.restoreState(state);
        }
        if (web.getUrl() == null) {
            web.loadUrl(START_URL);
        }
        cleanOldPdfs();
    }

    // ───────── الرجوع ─────────
    void handleBack() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            finish();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        handleBack();
    }

    /** ينفّذ جافاسكريبت في التطبيق (من أي thread) */
    void js(final String code) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (web != null) web.evaluateJavascript(code, null);
            }
        });
    }

    void setEntitled(boolean on) {
        js("window.__sirEntitlement&&window.__sirEntitlement(" + (on ? "true" : "false") + ")");
    }

    void adDone(boolean shown) {
        js("window.__sirAdDone&&window.__sirAdDone(" + (shown ? "true" : "false") + ")");
    }

    void pdfReply(String cb, boolean ok, String reason) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", ok);
            if (reason != null) o.put("reason", reason);
            js("window.__sirPdf&&window.__sirPdf(" + JSONObject.quote(cb) + "," + JSONObject.quote(o.toString()) + ")");
        } catch (Exception ignored) {
        }
    }

    // ───────── PDF ─────────
    static String safeName(String name) {
        String n = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|\\n\\r\\t]+", " ").trim();
        if (n.isEmpty()) n = "CV";
        if (n.length() > 80) n = n.substring(0, 80);
        return n;
    }

    PrintAttributes a4() {
        return new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setResolution(new PrintAttributes.Resolution("pdf", "pdf", 600, 600))
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .build();
    }

    /** نافذة الطباعة بتاعة النظام (فيها «حفظ بصيغة PDF») */
    void printDialog(String name, String cb) {
        try {
            PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            PrintDocumentAdapter adapter = web.createPrintDocumentAdapter(name);
            pm.print(name, adapter, a4());
            pdfReply(cb, true, "dialog");
        } catch (Throwable t) {
            pdfReply(cb, false, "print");
        }
    }

    /** يعمل ملف PDF ويفتح المشاركة (واتساب، إيميل، Drive…) — ولو فشل يرجع لنافذة الطباعة */
    void sharePdf(final String name, final String cb) {
        if (pdfBusy) {
            pdfReply(cb, false, "busy");
            return;
        }
        pdfBusy = true;
        final File out = new File(new File(getCacheDir(), "pdf"), name + ".pdf");
        PrintDocumentAdapter adapter;
        try {
            adapter = web.createPrintDocumentAdapter(name);
        } catch (Throwable t) {
            pdfBusy = false;
            printDialog(name, cb);
            return;
        }
        try {
            SirPdfWriter.write(adapter, a4(), out, new SirPdfWriter.Done() {
                @Override
                public void ok(File file) {
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            pdfBusy = false;
                            openShare(file, name, cb);
                        }
                    });
                }

                @Override
                public void fail(String why) {
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            pdfBusy = false;
                            printDialog(name, cb);
                        }
                    });
                }
            });
        } catch (Throwable t) {
            pdfBusy = false;
            printDialog(name, cb);
        }
    }

    void openShare(File file, String name, String cb) {
        try {
            Uri uri = PdfProvider.uriFor(file);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("application/pdf");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_TITLE, name + ".pdf");
            send.setClipData(ClipData.newRawUri(name, uri));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "مشاركة السيرة الذاتية"));
            pdfReply(cb, true, null);
        } catch (Throwable t) {
            printDialog(name, cb);
        }
    }

    void cleanOldPdfs() {
        try {
            File dir = new File(getCacheDir(), "pdf");
            File[] list = dir.listFiles();
            if (list == null) return;
            long old = System.currentTimeMillis() - 24L * 60 * 60 * 1000;
            for (File f : list) {
                if (f.lastModified() < old) f.delete();
            }
        } catch (Throwable ignored) {
        }
    }

    final class Bridge {
        @JavascriptInterface
        public String platform() {
            return "android";
        }

        /** action = share | print */
        @JavascriptInterface
        public void pdf(final String action, final String name, final String cb) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (web == null) return;
                    String n = safeName(name);
                    if ("print".equals(action)) printDialog(n, cb);
                    else sharePdf(n, cb);
                }
            });
        }

        /** action = preload | interstitial */
        @JavascriptInterface
        public void ads(final String action) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (ads == null) return;
                    if ("interstitial".equals(action)) ads.show();
                    else ads.start();
                }
            });
        }

        @JavascriptInterface
        @SuppressWarnings("deprecation")
        public void vibrate(int ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (v == null || !v.hasVibrator()) return;
                int d = Math.max(1, Math.min(ms, 300));
                if (Build.VERSION.SDK_INT >= 26) {
                    v.vibrate(VibrationEffect.createOneShot(d, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    v.vibrate(d);
                }
            } catch (Exception ignored) {
            }
        }

        /** «بلس»: action = offerings | purchase | restore */
        @JavascriptInterface
        public void billing(final String action, final String payload, final String cb) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (billing != null) billing.handle(action, payload, cb);
                }
            });
        }
    }

    // ───────── اختيار الصورة الشخصية (input type=file) ─────────
    final class Chrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = callback;
            try {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("image/*");
                startActivityForResult(Intent.createChooser(i, "اختر صورة"), REQ_FILE);
                return true;
            } catch (Exception e) {
                fileCallback = null;
                return false;
            }
        }
    }

    @Override
    protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req != REQ_FILE) return;
        ValueCallback<Uri[]> cb = fileCallback;
        fileCallback = null;
        if (cb == null) return;
        Uri[] value = null;
        if (result == RESULT_OK && data != null) {
            if (data.getData() != null) {
                value = new Uri[]{data.getData()};
            } else if (data.getClipData() != null && data.getClipData().getItemCount() > 0) {
                value = new Uri[]{data.getClipData().getItemAt(0).getUri()};
            }
        }
        cb.onReceiveValue(value);
    }

    // ───────── تحميل ملفات التطبيق من جوه الـAPK ─────────
    final class LocalClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (u == null || !HOST.equals(u.getHost())) return null;
            String path = u.getPath();
            if (path == null || path.isEmpty() || "/".equals(path)) path = "/index.html";
            if (path.contains("..")) return notFound();
            try {
                InputStream in = getAssets().open("www" + path);
                WebResourceResponse r = new WebResourceResponse(mime(path), "UTF-8", in);
                Map<String, String> h = new HashMap<String, String>();
                h.put("Cache-Control", "no-cache");
                r.setResponseHeaders(h);
                return r;
            } catch (IOException e) {
                return notFound();
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (u != null && HOST.equals(u.getHost())) return false;
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, u));
            } catch (Exception ignored) {
            }
            return true;
        }
    }

    static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    static String mime(String p) {
        String l = p.toLowerCase(Locale.ROOT);
        if (l.endsWith(".html")) return "text/html";
        if (l.endsWith(".js") || l.endsWith(".mjs")) return "text/javascript";
        if (l.endsWith(".css")) return "text/css";
        if (l.endsWith(".json")) return "application/json";
        if (l.endsWith(".webp")) return "image/webp";
        if (l.endsWith(".png")) return "image/png";
        if (l.endsWith(".jpg") || l.endsWith(".jpeg")) return "image/jpeg";
        if (l.endsWith(".svg")) return "image/svg+xml";
        if (l.endsWith(".woff2")) return "font/woff2";
        if (l.endsWith(".woff")) return "font/woff";
        if (l.endsWith(".txt")) return "text/plain";
        return "application/octet-stream";
    }

    // ───────── دورة حياة الشاشة ─────────
    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (billing != null) {
            billing.end();
            billing = null;
        }
        if (web != null) {
            web.removeJavascriptInterface("SiratyNative");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    // ───────── أكواد خاصة بإصدارات أندرويد الجديدة ─────────
    @android.annotation.TargetApi(30)
    static final class Api30 {
        static void edgeToEdge(Window w, View root) {
            w.setDecorFitsSystemWindows(false);
            android.view.WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                // أيقونات شريط الحالة داكنة (الخلفية فاتحة)
                int light = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                c.setSystemBarsAppearance(light, light);
            }
            root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                @Override
                public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                    android.graphics.Insets i = insets.getInsets(
                            WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                    v.setPadding(i.left, i.top, i.right, i.bottom);
                    return WindowInsets.CONSUMED;
                }
            });
        }
    }

    @android.annotation.TargetApi(33)
    static final class Api33 {
        static void registerBack(final MainActivity a) {
            a.getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                    new android.window.OnBackInvokedCallback() {
                        @Override
                        public void onBackInvoked() {
                            a.handleBack();
                        }
                    });
        }
    }
}
