package android.print;

import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;

import java.io.File;

/**
 * بيكتب ملف PDF من PrintDocumentAdapter بتاع الـWebView مباشرة (من غير نافذة الطباعة).
 * لازم يكون في الحزمة android.print عشان الـcallbacks دي مش متاحة برا الحزمة.
 * لو الجهاز رفض (أي Throwable) التطبيق بيرجع لنافذة الطباعة العادية.
 */
public final class SirPdfWriter {

    public interface Done {
        void ok(File file);

        void fail(String why);
    }

    private SirPdfWriter() {
    }

    public static void write(final PrintDocumentAdapter adapter, final PrintAttributes attrs, final File out, final Done done) {
        try {
            adapter.onStart();
            adapter.onLayout(null, attrs, new CancellationSignal(), new PrintDocumentAdapter.LayoutResultCallback() {
                @Override
                public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                    writePages(adapter, out, done);
                }

                @Override
                public void onLayoutFailed(CharSequence error) {
                    finish(adapter);
                    done.fail("layout: " + error);
                }

                @Override
                public void onLayoutCancelled() {
                    finish(adapter);
                    done.fail("cancelled");
                }
            }, new Bundle());
        } catch (Throwable t) {
            finish(adapter);
            done.fail(String.valueOf(t));
        }
    }

    private static void writePages(final PrintDocumentAdapter adapter, final File out, final Done done) {
        final ParcelFileDescriptor fd;
        try {
            File dir = out.getParentFile();
            if (dir != null && !dir.exists()) dir.mkdirs();
            fd = ParcelFileDescriptor.open(out, ParcelFileDescriptor.MODE_CREATE
                    | ParcelFileDescriptor.MODE_TRUNCATE | ParcelFileDescriptor.MODE_READ_WRITE);
        } catch (Throwable t) {
            finish(adapter);
            done.fail("open: " + t);
            return;
        }
        try {
            adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES}, fd, new CancellationSignal(),
                    new PrintDocumentAdapter.WriteResultCallback() {
                        @Override
                        public void onWriteFinished(PageRange[] pages) {
                            close(fd);
                            finish(adapter);
                            if (out.length() > 0) done.ok(out);
                            else done.fail("empty");
                        }

                        @Override
                        public void onWriteFailed(CharSequence error) {
                            close(fd);
                            finish(adapter);
                            done.fail("write: " + error);
                        }

                        @Override
                        public void onWriteCancelled() {
                            close(fd);
                            finish(adapter);
                            done.fail("cancelled");
                        }
                    });
        } catch (Throwable t) {
            close(fd);
            finish(adapter);
            done.fail(String.valueOf(t));
        }
    }

    private static void close(ParcelFileDescriptor fd) {
        try {
            fd.close();
        } catch (Throwable ignored) {
        }
    }

    private static void finish(PrintDocumentAdapter adapter) {
        try {
            adapter.onFinish();
        } catch (Throwable ignored) {
        }
    }
}
