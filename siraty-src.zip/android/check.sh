#!/usr/bin/env bash
# فحص سريع إن كود الجافا بيتجمّع صح ضد Android 36 + مكتبات الدفع والإعلانات (من غير Gradle).
# البناء الحقيقي بيتم في GitHub Actions (.github/workflows/android.yml)
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
SDK="${ANDROID_SDK:-/opt/android-sdk}"
JAR="$SDK/platforms/android-36/android.jar"
LIB="$HERE/build/check-libs"
OUT="$HERE/build/check-classes"
STUB="$HERE/build/check-stub/com/siraty/cv"
mkdir -p "$LIB" "$STUB"
get() { # $1 = مسار maven، $2 = اسم الملف
  [ -f "$LIB/$2.jar" ] && return
  curl -sfS -o "$LIB/$2.aar" "https://dl.google.com/dl/android/maven2/$1" && (cd "$LIB" && unzip -q -o "$2.aar" classes.jar && mv classes.jar "$2.jar" && rm "$2.aar")
}
get com/android/billingclient/billing/9.1.0/billing-9.1.0.aar billing
get com/google/android/gms/play-services-ads-api/24.7.0/play-services-ads-api-24.7.0.aar ads-api
echo 'package com.siraty.cv; public final class BuildConfig { public static final boolean DEBUG = false; public static final String ADMOB_INTERSTITIAL = "x"; }' > "$STUB/BuildConfig.java"
rm -rf "$OUT" && mkdir -p "$OUT"
javac -source 17 -target 17 -nowarn -classpath "$JAR:$LIB/billing.jar:$LIB/ads-api.jar" -encoding UTF-8 -Xlint:-options \
  -d "$OUT" $(find "$HERE/app/src/main/java" -name '*.java') "$STUB/BuildConfig.java" 2>&1 | grep -v "JAVA_TOOL_OPTIONS" || true
ls "$OUT/com/siraty/cv" "$OUT/android/print" | wc -l
