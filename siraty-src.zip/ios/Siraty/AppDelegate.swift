import UIKit

/// «سيرتي» — غلاف آيفون بسيط: WKWebView بيعرض التطبيق من ملفاته (من غير إنترنت)،
/// وجسر للجافاسكريبت بنفس أسماء نسخة أندرويد (SiratyNative): PDF، «بلس»، الإعلانات، والاهتزاز.
@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        let w = UIWindow(frame: UIScreen.main.bounds)
        w.backgroundColor = SiratyTheme.paper
        w.rootViewController = WebViewController()
        w.makeKeyAndVisible()
        window = w
        return true
    }
}

enum SiratyTheme {
    static let paper = UIColor(red: 244.0 / 255.0, green: 241.0 / 255.0, blue: 236.0 / 255.0, alpha: 1)
}
